# Abiss optional watershed agglomeration: corresponding source and rebuild

## Provenance and licensing

- Upstream: https://github.com/seung-lab/abiss
- Branch: `watershed-wasm-agglomeration`, based on `watershed-wasm` (`6153122`).
- Base Abiss commit: `8893da763a1630c6f2c25d6059fef26c13d72889` (recorded in `SOURCE_COMMIT`).
- `abiss/` contains the complete 113-file tracked source tree from that commit **with one local build-configuration patch**, not an unmodified upstream export. `abiss/CMakeLists.txt:32` changes only `-sMAXIMUM_MEMORY=2147483648` to `-sMAXIMUM_MEMORY=4294967296`; see `patches/maximum-memory-4gib.patch`. It is already applied; do not apply it again. No algorithm, wrapper, header, or upstream checkout was changed.
- Abiss and the supplemental build/verification files are GPL-3.0-or-later; see `LICENSE` and `abiss/LICENSE`.
- `third_party/boost/` contains 682 exact Boost 1.90.0 headers needed by the tested Emscripten and native core builds, selected from compiler dependency files, plus Boost Software License 1.0. They are not the entire Boost distribution.
- `licenses/` contains Emscripten, libc++, libc++abi, compiler-rt and musl notices from the actual SDK used. The standard compiler/runtime is obtained separately using the pinned recipe below.
- The source bundle includes the matching `abiss_watershed.wasm`, tests, fixtures, ABI declaration, build script and content checksums. Retain source availability and GPL notices when distributing the binary. No deployment was performed.

The delivered module is **87,429 bytes**. SHA-256:

```text
7d7dcf0e989f2f0cdcab6acf17bf23b655254cc6b4faff9cfc9f1975d773e825
```

## Local 4 GiB ceiling, not preallocation

The unshared wasm32 memory has an initial **256 pages (16 MiB)** and a maximum
**65,536 pages (4,294,967,296 bytes, 4 GiB)**. `ALLOW_MEMORY_GROWTH=1` is unchanged;
this does not preallocate 4 GiB. The previous agglomerating module had the same
initial size and a maximum of 32,768 pages (2 GiB). Browsers may still reject
large allocations, and increasing the ceiling does not prove all 64Mi-voxel
jobs fit. Full-size Chrome tests are outside this native-build verification.

The new binary differs from that 2 GiB module at exactly one byte: zero-based
offset 408 changes from `0x02` to `0x04` in the memory section. Every other
binary section, including code, imports, function types and exports, is
byte-identical. `verify_memory_4gib.cjs` checks the declared limits, actual
16 MiB instance size, complete ABI, and optionally this old/new comparison.
The old modules are deliberately not bundled; their hashes and original raw
verification reports remain as historical evidence, not new test results.

## Toolchain truth

This binary was built with Emscripten **3.1.69-git**, not the 4.0.15 SDK used for the previous watershed-only binary:

```text
emcc 3.1.69-git (c55ff404dbe1eb9f263c48b584d5ba627224763a)
clang 20.0.0git (50866e84d1da8462aeb96607bf6d9e5bbd5869c5)
Target: wasm32-unknown-emscripten
CMake 4.2.3
Node.js v24.18.0
Boost 1.90.0 (headers included)
```

The official emsdk releases mapping resolved `3.1.69` to release hash
`8fe01288bc35668c13316324336ea00195dfb814`. The immutable Linux SDK archive is:

```text
https://storage.googleapis.com/webassembly/emscripten-releases-builds/linux/8fe01288bc35668c13316324336ea00195dfb814/wasm-binaries.tar.xz
```

Archive size: 304,772,336 bytes. Archive SHA-256:

```text
24a786666e6f48ed3c3944b44df5cf146c45cf4faece4cb2686312a3d052a00c
```

## Clean, byte-identical Linux rebuild

Extract this source archive into a fresh directory, then verify its contents:

```sh
sha256sum -c SHA256SUMS
```

Install CMake and Node.js, and fetch the pinned SDK outside the source directory:

```sh
sdk="$PWD/../abiss-pinned-sdk"
mkdir -p "$sdk"
curl -fL 'https://storage.googleapis.com/webassembly/emscripten-releases-builds/linux/8fe01288bc35668c13316324336ea00195dfb814/wasm-binaries.tar.xz' \
  -o "$sdk/wasm-binaries.tar.xz"
printf '%s  %s\n' \
  '24a786666e6f48ed3c3944b44df5cf146c45cf4faece4cb2686312a3d052a00c' \
  "$sdk/wasm-binaries.tar.xz" | sha256sum -c -
tar -xJf "$sdk/wasm-binaries.tar.xz" -C "$sdk"
export EM_CONFIG=/dev/null
export PATH="$sdk/install/emscripten:$sdk/install/bin:$PATH"
./build.sh "$PWD/../abiss-wasm-build"
```

`build.sh` uses only the bundled Boost header directory, disables native tools, enables native WebAssembly exceptions, builds Release, runs the env-only runtime test, and compares the rebuilt module byte-for-byte with the included binary. A fresh-source rebuild and a rebuild from the newly extracted archive were executed successfully for this 4 GiB binary; see `VERIFICATION.md` and `evidence/heap-4gib/`. Both SDK PATH entries above are required (`install/bin` supplies Binaryen and LLVM); no global SDK installation is needed. Do not add `/usr/include` to Emscripten's include path.

Inspect the memory declaration and exact ABI without any large allocation:

```sh
node verify_memory_4gib.cjs
```

The effective application configuration is:

```sh
emcmake cmake -S abiss -B build-wasm \
  -DABISS_BUILD_WASM=ON -DABISS_BUILD_NATIVE_TOOLS=OFF \
  -DBUILD_TESTING=ON -DCMAKE_BUILD_TYPE=Release \
  -DBoost_NO_BOOST_CMAKE=ON -DBoost_NO_SYSTEM_PATHS=ON \
  -DBoost_INCLUDE_DIR="$PWD/third_party/boost"
cmake --build build-wasm --parallel 2
ctest --test-dir build-wasm --output-on-failure
```

For the native C++17 core tests (no native distributed tools):

```sh
cmake -S abiss -B build-native -DABISS_BUILD_NATIVE_TOOLS=OFF \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_STANDARD=17 \
  -DBoost_NO_BOOST_CMAKE=ON -DBoost_NO_SYSTEM_PATHS=ON \
  -DBoost_INCLUDE_DIR="$PWD/third_party/boost"
cmake --build build-native --parallel 2
ctest --test-dir build-native --output-on-failure
```

Historical verification of the previous 2 GiB build found full legacy native-tool configuration blocked by the host's missing Boost.System 1.90 package; direct native agglomerator compilation and eight file-output regression cases passed then. Those checks were not rerun for this build-flag-only change. The current native core CTest suite was rebuilt and passed all five tests; distributed native tools are not required.

## Browser runtime and C ABI

The module has exactly one import:

```text
env.emscripten_notify_memory_growth(memory_index_i32) -> void
```

No WASI runtime, Emscripten JavaScript glue, filesystem, threads, SharedArrayBuffer or COOP/COEP is needed. The browser must support native WebAssembly exceptions.

```js
const instance = new WebAssembly.Instance(compiledModule, {
  env: { emscripten_notify_memory_growth() {} },
});
instance.exports._initialize(); // exactly once, before allocation or segmentation
```

See `abiss/src/ws/wasm.h` for exact C declarations. Exports include:

```text
memory
_initialize()
malloc(byte_count) -> pointer
free(pointer)
abiss_watershed(affinity_ptr, affinity_count, x, y, z,
  high_f32, low_f32, size_u32, dust_u32, labels_ptr, label_count) -> status_i32
abiss_watershed_agglomerate(affinity_ptr, affinity_count, x, y, z,
  high_f32, low_f32, size_u32, dust_u32, agg_threshold_f32,
  labels_ptr, label_count) -> status_i32
abiss_watershed_last_error() -> pointer to NUL-terminated UTF-8
```

The import's i32 argument was confirmed by binary type-section inspection; a JavaScript no-op callback may ignore it. The toolchain also exports `__indirect_function_table` (table) and `__trap() -> void`; application code does not call them. The ABI verifier checks these exports too. WebAssembly returns i32 pointers to JavaScript as signed numbers: normalize them with `>>> 0` before creating views or reading error strings, especially above 2 GiB.

Counts are elements, not bytes. Input is planar Float32 `(3,Z,Y,X)`, x fastest, channels to negative X/Y/Z. Affinity count is exactly `3*x*y*z`; label count exactly `x*y*z`. Output is Uint32 `(Z,Y,X)`, background 0. Callers own valid distinct input/output allocations. Affinities remain unchanged; output is written only on success. Refresh typed-array views after allocations/calls that may grow memory, and copy labels before freeing allocations.

Status: 0 success; 1 invalid input; 2 allocation failure; 3 other error. Both entry points share the error buffer; the next successful call clears it.

## Optional agglomeration semantics

- Disabled means call the original `abiss_watershed` export. Its ABI, thresholds, SIZE/DUST order and exact labels are preserved. In the C++ wrapper, omission/`std::nullopt` disables it.
- Enabled means call `abiss_watershed_agglomerate` with a finite `agg_threshold` in the inclusive range `[0,1]`. **Zero enables agglomeration, never disables it.** The native direct/demo default is 0.15; production opt-in remains disabled by default.
- Merge contacts strictly when `mean_affinity > agg_threshold`; equality does not merge. Scores are total affinity sum / contact area. Shared-neighbor updates add both sums and areas; weak and zero contacts remain included. This is neither max linkage nor an unweighted mean of pair scores.
- Watershed SIZE merging and DUST filtering happen **before** post-watershed agglomeration. There is no second dust filtering pass.
- Native size rejection remains: a mean <= 0.35 contact is rejected if both component sizes exceed 1,000,000 voxels and their combined size exceeds 10,000,000. No semantic/frozen-boundary data is supplied for a complete chunk.
- Background 0 is excluded from the graph and remains 0, so no contact bridges across background holes. Mask preprocessing is Neuroglancer's responsibility; Abiss receives the masked affinities/labels, not a separate mask.
- Output retains surviving watershed IDs and is **not recompacted** after agglomeration. Gaps in positive IDs are valid.

## Tie-order contract and disclosed verification limitation

Enabled agglomeration preserves the existing native greedy mean-linkage semantics. Equal scores have no endpoint-ID tie-break, and incident-map iteration can change the heap's tie order across implementations. There is **no cross-platform canonical-ID guarantee or general tied-graph partition guarantee** for enabled agglomeration. Surviving seed IDs, rather than portable/recompacted IDs, are the contract. Disabled watershed retains strict exact-label compatibility.

The new 4 GiB binary passes all 31 independent analytic cases (24 enabled), and all 128 seeded disabled previous-2-GiB/new-4-GiB/native exact-label comparisons. Its full enabled native/WASM exact-ID stress rerun yielded **127 passes and 1 failure**, again WASM ID 3 versus native ID 6 in case 120; the full verifier exits 1 honestly. New reports are under `evidence/heap-4gib/`; `required-results.json` explicitly skips enabled random checks, while `extended-results.json` records the failure.

Root-level `extended-results.json`, `verification-results.json`, `baseline-results.json`, replay/trace files and `evidence/superseded-same-binary-*.json` are **unchanged historical evidence for earlier binaries**, not executions against this rebuild. Historical case 120 analysis found identical background/partition for that particular case, stable IDs over repeated runs, and an equal-score tie (.75/2 = .375) following differing unordered incident traversal. No trace instrumentation or repeated partition-stability experiment was rerun for the 4 GiB build, and no algorithm change or canonicalization was made. See the clearly separated current and historical sections of `VERIFICATION.md`; `evidence/heap-4gib/original-BUILDING.md` preserves the earlier build notes verbatim. Old baseline binaries are not included, and their source/licensing must be handled separately if obtained for optional comparison.
