# Abiss complete-chunk watershed WASM

This is a distinct GPL-3.0-or-later component, not Apache-licensed code. Preserve the GPL license, source, attribution and third-party license notices when distributing. Packaging it separately does not by itself resolve licensing obligations for a combined application; review those before distribution.

## Provenance and reproducible build

- Abiss upstream: https://github.com/seung-lab/abiss
- Abiss branch: `watershed-wasm`, source commit `6153122` (wrapper `34e00bb`, based on core refactor through `fcf591d`). The complete tracked source snapshot is in `source/`; no uncommitted examples/tests/docs are required.
- Emscripten SDK `4.0.15`, emsdk tag commit `389a68bc35dcff7ebae4614e1615099dafda00d1`.
- SDK release build `b412b6307e541b93dd93f01b61181e15c17302ec`, compiler revision `09f52557f0d48b65b8c724853ed8f4e8bf80e669`.
- Boost `1.90.0` (Ubuntu package `libboost1.90-dev 1.90.0-6ubuntu1`); all 432 headers used by this build are included under `third_party/boost/boost/`, with their notices and the Boost license.
- Original build used Linux x86_64 and CMake `4.2.3`. CMake target `abiss_watershed_wasm`, Release (`-O3 -DNDEBUG`), C++17. All WASM flags are in `source/CMakeLists.txt`.
- Output `abiss_watershed.wasm`: 55,719 bytes; SHA-256 `39ee6d816fe53b4396ed5ba73ff36e719117a087a68d5eeaddbb6bb08d772c2b`.

Install the pinned SDK locally (no system package changes required):

```sh
git clone --depth 1 --branch 4.0.15 https://github.com/emscripten-core/emsdk.git emsdk
cd emsdk
./emsdk install 4.0.15
./emsdk activate 4.0.15
. ./emsdk_env.sh
cd /path/to/this/bundle
sh ./build.sh
```

`build.sh` configures from the bundled clean source and Boost headers, builds the WASM, prints its SHA-256, and compares it byte-for-byte with the included binary. The SDK supplies the compiler and runtime used by the build; Emscripten runtime sources are under its `upstream/emscripten/system/` tree. Runtime license notices are also supplied in `licenses/`. The archive's root `LICENSE` and `source/LICENSE` contain the GNU GPL v3.

## Standalone module ABI

No generated JavaScript, filesystem, threads, SharedArrayBuffer, COOP/COEP, Node APIs, or WASI host implementation is required. Native Wasm exception handling must be supported by the engine. The only import is:

```js
const imports = {env: {emscripten_notify_memory_growth() {}}};
const {instance} = await WebAssembly.instantiateStreaming(fetch(wasmURL), imports);
const e = instance.exports;
e._initialize(); // once per instance, before malloc or watershed
```

Use a server that returns `Content-Type: application/wasm` for streaming, or instantiate fetched ArrayBuffer bytes instead. Run watershed in a computation worker: initialization is async but the watershed call itself is synchronous. Memory is unshared, initially 16 MiB, growable up to 2 GiB; actual allocation limits may be lower.

Exports used by the caller:

```c
void _initialize(void);
void* malloc(uint32_t bytes); // returns 0 on allocation failure
void free(void* pointer);
int32_t abiss_watershed(
    const float* affinities, uint32_t affinity_count,
    uint32_t x, uint32_t y, uint32_t z,
    float high, float low, uint32_t size, uint32_t dust,
    uint32_t* labels, uint32_t label_count);
const char* abiss_watershed_last_error(void);
// memory is also exported as WebAssembly.Memory.
```

Pointers are wasm32 byte offsets. Counts are ELEMENTS, not bytes, and must equal `3*x*y*z` and `x*y*z` exactly. Allocate distinct valid input/output buffers with the module's malloc, check for 0, and always free in a finally block. Arbitrary invalid pointers are not safe. Copy the input only after both allocations; recreate all typed-array views from `e.memory.buffer` after any allocation or watershed call, since memory growth detaches old views. Copy labels into JS-owned storage before freeing output memory.

Input is unpadded, planar float32 `[3,z,y,x]`, X fastest: `x + X*(y + Y*(z + Z*channel))`. Channels 0/1/2 connect the current voxel to its -X/-Y/-Z neighbor. Every affinity must be finite in [0,1], including boundary entries. All six ROI boundaries are real: outside-neighbor edges are ignored, and the core adds/removes its own one-voxel halo. No input halo or caller crop is needed.

All ABI options are explicit. Recommended JS defaults match the C++ API: `high=0.99999`, `low=0.00005`, `size=50`, `dust=50`. Require `0 <= low < high <= 1`. Dimensions are positive uint32 integers; size/dust are nonnegative uint32 integers. Validate JS numbers before u32 coercion to avoid wraparound. SIZE merges regions smaller than SIZE across contacts strictly greater than LOW; DUST removes surviving regions smaller than DUST, independently of SIZE. Either size or dust can be 0.

Output is unpadded uint32 `[z,y,x]`, X fastest, with 0 background and compact local positive labels. IDs are local to this entire invocation/ROI; independent tiled calls are NOT stitched and must not be represented as a global segmentation.

Status: 0 success, 1 invalid input, 2 allocation failure, 3 other caught error. The output buffer is not written on failure. `abiss_watershed_last_error()` returns a static NUL-terminated UTF-8 string, valid until the next watershed call; read/copy it immediately. The next successful call clears it. Input remains unchanged for valid, distinct allocations. Invalid inputs and caught allocation failures do not poison the instance; traps caused by invalid pointers or host failures are outside this recoverable-error contract.
