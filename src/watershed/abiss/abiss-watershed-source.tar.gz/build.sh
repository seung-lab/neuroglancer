#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BUILD=${1:-"$ROOT/build"}
VERSION=$(em++ --version)
case "$VERSION" in
  *" 4.0.15 "*) ;;
  *) echo "Use Emscripten 4.0.15; source its emsdk_env.sh first." >&2; exit 1 ;;
esac
emcmake cmake -S "$ROOT/source" -B "$BUILD" \
  -DCMAKE_BUILD_TYPE=Release \
  -DABISS_BUILD_WASM=ON -DABISS_BUILD_NATIVE_TOOLS=OFF \
  -DBoost_NO_BOOST_CMAKE=ON -DBoost_INCLUDE_DIR="$ROOT/third_party/boost"
cmake --build "$BUILD" --target abiss_watershed_wasm -j2
sha256sum "$BUILD/abiss_watershed.wasm"
cmp "$ROOT/abiss_watershed.wasm" "$BUILD/abiss_watershed.wasm"
