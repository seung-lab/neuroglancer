#!/bin/sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
build=${1:-"$root/build-wasm"}
emcmake cmake -S "$root/abiss" -B "$build" \
    -DABISS_BUILD_WASM=ON -DABISS_BUILD_NATIVE_TOOLS=OFF \
    -DBUILD_TESTING=ON -DCMAKE_BUILD_TYPE=Release \
    -DBoost_NO_BOOST_CMAKE=ON -DBoost_NO_SYSTEM_PATHS=ON \
    -DBoost_INCLUDE_DIR="$root/third_party/boost"
cmake --build "$build" --parallel 2
ctest --test-dir "$build" --output-on-failure
if [ -f "$root/abiss_watershed.wasm" ]; then
    cmp "$root/abiss_watershed.wasm" "$build/abiss_watershed.wasm"
    printf '%s\n' 'Rebuilt WASM is byte-identical to the delivered binary.'
fi
