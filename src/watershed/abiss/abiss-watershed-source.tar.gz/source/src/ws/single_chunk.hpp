#pragma once

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <memory>
#include <stdexcept>
#include <utility>
#include <vector>

#include "basic_watershed.hpp"
#include "region_graph.hpp"
#include "agglomeration.hpp"

namespace abiss {

inline std::size_t chunk_voxel_count(std::size_t xdim, std::size_t ydim, std::size_t zdim)
{
    // Bound both watershed IDs and addressable affinity bytes, including on wasm32.
    const auto limit = std::min<std::size_t>(
        watershed_traits<uint32_t>::high_bit - 1,
        std::numeric_limits<std::ptrdiff_t>::max() / (3 * sizeof(float)));
    std::size_t padded_count = 1;
    for (auto dim : {xdim, ydim, zdim}) {
        if (dim == 0 || dim > limit - 2 || padded_count > limit / (dim + 2)) {
            throw std::invalid_argument("chunk dimensions are empty or too large");
        }
        padded_count *= dim + 2;
    }
    return xdim * ydim * zdim;
}

// Input: unpadded float32 (X,Y,Z,3), x fastest, channel slowest; negative-neighbor edges.
// All six boundaries are real. Input is unchanged; the one-voxel halo is internal only.
// Output: unpadded uint32 (X,Y,Z), x fastest; label 0 is background.
// SIZE merges regions smaller than SIZE across contacts > LOW; DUST removes survivors < DUST.
inline std::vector<uint32_t> watershed_chunk(
    const float* affinities, std::size_t xdim, std::size_t ydim, std::size_t zdim,
    float high_threshold = 0.99999f, float low_threshold = 0.00005f,
    std::size_t size_threshold = 50, std::size_t dust_threshold = 50)
{
    const auto voxel_count = chunk_voxel_count(xdim, ydim, zdim);
    if (affinities == nullptr) {
        throw std::invalid_argument("affinity buffer must not be null");
    }
    // Real-boundary edges are masked to LOW, so HIGH must stay above that sentinel.
    if (!(0 <= low_threshold && low_threshold < high_threshold && high_threshold <= 1)) {
        throw std::invalid_argument("thresholds must satisfy 0 <= LOW < HIGH <= 1");
    }

    const auto px = xdim + 2;
    const auto py = ydim + 2;
    const auto pz = zdim + 2;
    std::vector<float> padded(px * py * pz * 3, 0);
    auto aff = std::make_shared<affinity_graph<float>>(
        padded.data(), boost::extents[px][py][pz][3], boost::fortran_storage_order());
    std::size_t index = 0;
    for (std::size_t channel = 0; channel < 3; ++channel)
        for (std::size_t z = 0; z < zdim; ++z)
            for (std::size_t y = 0; y < ydim; ++y)
                for (std::size_t x = 0; x < xdim; ++x) {
                    const auto value = affinities[index++];
                    if (!std::isfinite(value) || value < 0 || value > 1) {
                        throw std::invalid_argument("affinities must be finite values in [0, 1]");
                    }
                    (*aff)[x + 1][y + 1][z + 1][channel] = value;
                }

    const std::array<bool, 6> boundaries{{true, true, true, true, true, true}};
    auto [seg, counts] = watershed<uint32_t>(aff, low_threshold, high_threshold, boundaries);
    auto graph = get_region_graph(aff, seg, counts.size() - 1, low_threshold, boundaries);
    merge_segments(seg, graph, counts, std::make_pair(size_threshold, low_threshold), dust_threshold);

    std::vector<uint32_t> labels(voxel_count);
    index = 0;
    for (std::size_t z = 0; z < zdim; ++z)
        for (std::size_t y = 0; y < ydim; ++y)
            for (std::size_t x = 0; x < xdim; ++x)
                labels[index++] = (*seg)[x + 1][y + 1][z + 1];
    return labels;
}

} // namespace abiss
