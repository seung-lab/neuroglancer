# Abiss optional watershed agglomeration: corresponding source and rebuild

## Provenance and licensing

- Upstream: https://github.com/seung-lab/abiss
- Branch: `watershed-wasm-agglomeration`, based on `watershed-wasm` (`6153122`).
- Exact Abiss commit: `8893da763a1630c6f2c25d6059fef26c13d72889` (recorded in `SOURCE_COMMIT`).
- `abiss/` is the complete tracked source tree exported from that commit; no working-tree or unrelated untracked files were used.
- Abiss and the supplemental build/verification files are GPL-3.0-or-later; see `LICENSE` and `abiss/LICENSE`.
- `third_party/boost/` contains 682 exact Boost 1.90.0 headers needed by the tested Emscripten and native core builds, selected from compiler dependency files, plus Boost Software License 1.0. They are not the entire Boost distribution.
- `licenses/` contains Emscripten, libc++, libc++abi, compiler-rt and musl notices from the actual SDK used. The standard compiler/runtime is obtained separately using the pinned recipe below.
- The source bundle includes the matching `abiss_watershed.wasm`, tests, fixtures, ABI declaration, build script and content checksums. Retain source availability and GPL notices when distributing the binary. No deployment was performed.

The delivered module is **87,429 bytes**. SHA-256:

```text
fb8c6031c5d5fb5b826e32522a7c391364079c9f628ef53cc79b5b91d6174bba
```

## Toolchain truth

This binary was built with Emscripten **3.1.69-git**, not the 4.0.15 SDK used for the previous watershed-only binary:

```text
emcc 3.1.69-git (c55ff404dbe1eb9f263c48b584d5ba627224763a)
clang 20.0.0git (50866e84d1da8462aeb96607bf6d9e5bbd5869c5)
Target: wasm32-unknown-emscripten
CMake 4.2.3
Node.js v24.18.0
Boost 1.90.0 (headers included)
```

The official emsdk releases mapping resolved `3.1.69` to release hash
`8fe01288bc35668c13316324336ea00195dfb814`. The immutable Linux SDK archive is:

```text
https://storage.googleapis.com/webassembly/emscripten-releases-builds/linux/8fe01288bc35668c13316324336ea00195dfb814/wasm-binaries.tar.xz
```

Archive size: 304,772,336 bytes. Archive SHA-256:

```text
24a786666e6f48ed3c3944b44df5cf146c45cf4faece4cb2686312a3d052a00c
```

## Clean, byte-identical Linux rebuild

Extract this source archive into a fresh directory, then verify its contents:

```sh
sha256sum -c SHA256SUMS
```

Install CMake and Node.js, and fetch the pinned SDK outside the source directory:

```sh
sdk="$PWD/../abiss-pinned-sdk"
mkdir -p "$sdk"
curl -fL 'https://storage.googleapis.com/webassembly/emscripten-releases-builds/linux/8fe01288bc35668c13316324336ea00195dfb814/wasm-binaries.tar.xz' \
  -o "$sdk/wasm-binaries.tar.xz"
printf '%s  %s\n' \
  '24a786666e6f48ed3c3944b44df5cf146c45cf4faece4cb2686312a3d052a00c' \
  "$sdk/wasm-binaries.tar.xz" | sha256sum -c -
tar -xJf "$sdk/wasm-binaries.tar.xz" -C "$sdk"
export EM_CONFIG=/dev/null
export PATH="$sdk/install/emscripten:$sdk/install/bin:$PATH"
./build.sh "$PWD/../abiss-wasm-build"
```

`build.sh` uses only the bundled Boost header directory, disables native tools, enables native WebAssembly exceptions, builds Release, runs the env-only runtime test, and compares the rebuilt module byte-for-byte with the included binary. This exact clean-source/bundled-header rebuild was executed successfully, not merely proposed. Do not add `/usr/include` to Emscripten's include path.

The effective application configuration is:

```sh
emcmake cmake -S abiss -B build-wasm \
  -DABISS_BUILD_WASM=ON -DABISS_BUILD_NATIVE_TOOLS=OFF \
  -DBUILD_TESTING=ON -DCMAKE_BUILD_TYPE=Release \
  -DBoost_NO_BOOST_CMAKE=ON -DBoost_NO_SYSTEM_PATHS=ON \
  -DBoost_INCLUDE_DIR="$PWD/third_party/boost"
cmake --build build-wasm --parallel 2
ctest --test-dir build-wasm --output-on-failure
```

For the native C++17 core tests (no native distributed tools):

```sh
cmake -S abiss -B build-native -DABISS_BUILD_NATIVE_TOOLS=OFF \
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_STANDARD=17 \
  -DBoost_NO_BOOST_CMAKE=ON -DBoost_NO_SYSTEM_PATHS=ON \
  -DBoost_INCLUDE_DIR="$PWD/third_party/boost"
cmake --build build-native --parallel 2
ctest --test-dir build-native --output-on-failure
```

Full legacy native-tool configuration on the build host is independently blocked by its missing Boost.System 1.90 package; this is not required for the core or WASM builds. Direct native agglomerator compilation and eight before/after file-output regression cases passed unchanged.

## Browser runtime and C ABI

The module has exactly one import:

```text
env.emscripten_notify_memory_growth() -> void
```

No WASI runtime, Emscripten JavaScript glue, filesystem, threads, SharedArrayBuffer or COOP/COEP is needed. The browser must support native WebAssembly exceptions.

```js
const instance = new WebAssembly.Instance(compiledModule, {
  env: { emscripten_notify_memory_growth() {} },
});
instance.exports._initialize(); // exactly once, before allocation or segmentation
```

See `abiss/src/ws/wasm.h` for exact C declarations. Exports include:

```text
memory
_initialize()
malloc(byte_count) -> pointer
free(pointer)
abiss_watershed(affinity_ptr, affinity_count, x, y, z,
  high_f32, low_f32, size_u32, dust_u32, labels_ptr, label_count) -> status_i32
abiss_watershed_agglomerate(affinity_ptr, affinity_count, x, y, z,
  high_f32, low_f32, size_u32, dust_u32, agg_threshold_f32,
  labels_ptr, label_count) -> status_i32
abiss_watershed_last_error() -> pointer to NUL-terminated UTF-8
```

Counts are elements, not bytes. Input is planar Float32 `(3,Z,Y,X)`, x fastest, channels to negative X/Y/Z. Affinity count is exactly `3*x*y*z`; label count exactly `x*y*z`. Output is Uint32 `(Z,Y,X)`, background 0. Callers own valid distinct input/output allocations. Affinities remain unchanged; output is written only on success. Refresh typed-array views after allocations/calls that may grow memory, and copy labels before freeing allocations.

Status: 0 success; 1 invalid input; 2 allocation failure; 3 other error. Both entry points share the error buffer; the next successful call clears it.

## Optional agglomeration semantics

- Disabled means call the original `abiss_watershed` export. Its ABI, thresholds, SIZE/DUST order and exact labels are preserved. In the C++ wrapper, omission/`std::nullopt` disables it.
- Enabled means call `abiss_watershed_agglomerate` with a finite `agg_threshold` in the inclusive range `[0,1]`. **Zero enables agglomeration, never disables it.** The native direct/demo default is 0.15; production opt-in remains disabled by default.
- Merge contacts strictly when `mean_affinity > agg_threshold`; equality does not merge. Scores are total affinity sum / contact area. Shared-neighbor updates add both sums and areas; weak and zero contacts remain included. This is neither max linkage nor an unweighted mean of pair scores.
- Watershed SIZE merging and DUST filtering happen **before** post-watershed agglomeration. There is no second dust filtering pass.
- Native size rejection remains: a mean <= 0.35 contact is rejected if both component sizes exceed 1,000,000 voxels and their combined size exceeds 10,000,000. No semantic/frozen-boundary data is supplied for a complete chunk.
- Background 0 is excluded from the graph and remains 0, so no contact bridges across background holes. Mask preprocessing is Neuroglancer's responsibility; Abiss receives the masked affinities/labels, not a separate mask.
- Output retains surviving watershed IDs and is **not recompacted** after agglomeration. Gaps in positive IDs are valid.

## Tie-order contract and disclosed verification limitation

Enabled agglomeration preserves the existing native greedy mean-linkage semantics. Equal scores have no endpoint-ID tie-break, and incident-map iteration can change the heap's tie order across implementations. There is **no cross-platform canonical-ID guarantee or general tied-graph partition guarantee** for enabled agglomeration. Surviving seed IDs, rather than portable/recompacted IDs, are the contract. Disabled watershed retains strict exact-label compatibility.

The independent analytic suite passes all 31 cases (24 enabled), and all 128 seeded disabled old/new/native exact-label cases pass. An additional 128 enabled native/WASM exact-ID stress checks yielded **127 passes and 1 failure**, which is disclosed rather than counted as an all-exact pass. Preserved case 120 has the same 13 background voxels and one identical 71-voxel foreground component, but WASM preserves ID 3 and native ID 6, stable over five WASM instances/ten native processes. Temporary trace builds confirm unordered incident iteration differs after the first merge and the first selected-merge divergence is an exact equal-score tie (.75/2 = .375), not float threshold drift. Diagnostic outputs match the unmodified delivered binary. No algorithm change or canonicalization was made just to force portable IDs.

`fixtures.json` and the supplemental verifier exercise independent analytic threshold/mean-linkage cases as well as exact disabled-old-binary/native/WASM parity. `VERIFICATION.md` contains the executed commands, complete outcomes and failure replay. `extended-results.json` remains FAIL; `verification-results.json` is an explicitly scoped required-suite PASS that skips the separately disclosed enabled stress test. The verifier's default full run still exits 1 for that documented exact-ID discrepancy. This limitation is independent of the clean, byte-identical source rebuild, which passes.
