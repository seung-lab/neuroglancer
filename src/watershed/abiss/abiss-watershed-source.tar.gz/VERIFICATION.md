# Verification — required suite PASS; enabled exact-ID stress has a limitation

Tested final source commit `8893da763a1630c6f2c25d6059fef26c13d72889`, using
Node v24.18.0 and g++ 15.2.0, C++17/O2, exported source and vendored Boost 1.90.
No repository, exported-source, delivered-binary, or application-code edits were
made. Diagnostic instrumentation was confined to a temporary source copy.

| Check | Result |
|---|---|
| 31 independent analytic fixtures (24 enabled, 7 disabled), exact labels | PASS new WASM/native; disabled cases also PASS old WASM |
| Slabs on all axes; strict .25 mean; .3 vs maximum .375 | PASS |
| Dynamic NG-peer .58 preserves ID 3 gap; .55 merges all | PASS |
| 128 seeded disabled cases: old/new/native exact labels | PASS |
| Extra 128 enabled new/native exact-ID stress cases | **127 PASS, 1 FAIL** |
| Failing case: background/partition and output stability over 5 independent runs | PASS; **exact survivor IDs still differ** |

Both WASM modules import **only** `env.emscripten_notify_memory_growth`.
Each instance calls `_initialize` exactly once. Direct WebAssembly APIs only:
no WASI runtime/polyfill. Inputs are checked unchanged; errors/status checked.

## Honest failure evidence

`extended-results.json` is the full **FAIL** report, with no random skips.
`verification-results.json` is a separately scoped **PASS** run using
`--skip-enabled-random` to isolate the required analytic/disabled suite. That
option was introduced **after a full run failed**; it is not evidence that
arbitrary enabled exact-ID parity passes. Default verification includes the
extra stress tests and currently exits 1. No expected labels were blessed or
changed to hide the failure, and no output IDs are canonicalized by the verifier.

Case `seed_ab155ed_120_style7_enabled`: dims `[7,4,3]`, HIGH=.625, LOW=.5,
SIZE=2, DUST=2, agg=0; affinities use the repeating dyadic values 0/.25/.5/.75.
Across **five independent WASM instances and native process runs**, disabled
labels match exactly; enabled outputs have identical background (13/84 voxels)
and one identical 71-voxel foreground component. WASM consistently preserves
ID **3**, native consistently preserves ID **6**. First-encounter partition
canonicalization, preserving zero, matches exactly. This is an observed
survivor-ID discrepancy, not an observed partition discrepancy.

Root evidence: `repro_case120.json`, `repro_case120.bin`,
`repro_case120.cjs`, `repro_case120_outputs.json`; `repro_native_runner` is the
preserved native executable. Full failed cases and native executables also
remain in the build directories named in the reports. Both system-Boost and
vendored-Boost native builds reproduced ID 6.

**Actual divergence confirmed by temporary native/WASM trace builds.** Both
instrumented outputs were compared exactly against the original outputs and
match, including WASM ID 3/native ID 6. `repro_case120_trace.json` preserves all
21 selected merges and incident visits for each build;
`repro_case120_trace.patch` records the copied-header instrumentation.

- First merge is `(1,19,sum=.5,area=1) -> 1` in both. The next incident visit
  already differs: WASM `19 -> 15` (sum .25, area 1), native `19 -> 21` (sum 0,
  area 1). This is observed unordered-map iteration divergence.
- First six selected merges agree: `(1,19)`, `(2,16)`, `(3,20)`, `(4,18)`,
  `(5,21)`, `(6,22)`, each mean .5.
- **Merge 7 is the first selected-merge divergence:** WASM selects `(8,12)` with
  sum .75, area 2, mean .375, counts 1/1, survivor 8. Native selects `(5,9)` with
  the **same sum .75, area 2, mean .375**, counts 2/1, survivor 5.

`abiss/src/agg/edges.h:33-39` compares only `sum/num`, with no endpoint tie-break;
`abiss/src/agg/agglomeration.hpp:60-73` uses that comparison in a Fibonacci heap;
`abiss/src/agg/agglomeration.hpp:359-398` updates the heap while traversing an
unordered incident map. Survivor choice uses `auto s = v0` at line 259 and
supervoxel-count comparison at lines 310-313. The traces establish actual
unordered-visit and equal-score merge-order divergence, not merely a hypothesis.
Recommended contract: preserve existing native kernel semantics and original,
noncompact survivor IDs, but **do not promise portable canonical IDs for tied
enabled graphs**. No kernel/wrapper fix or output renumbering was attempted.

Diagnostic-only sources, helper code, executables and instrumented WASM remain
at `/tmp/abiss-case120-trace`; that instrumented WASM is **not** the delivered
binary. Native used g++ C++17/O2; diagnostic WASM used the existing Emscripten
toolchain, C++17/O3, wasm exceptions, standalone/filesystem-off, and only the env
growth import. The delivered 87,429-byte WASM retains the hash below.

## Baseline provenance correction

During testing the external Neuroglancer binary path changed to the new binary
(same hash), invalidating early final-run old/new comparisons. Those reports
are retained in `evidence/superseded-same-binary-*.json`, not used as parity
proof. The original was recovered read-only from Neuroglancer Git HEAD
`bed7fec39bcea84c4994cda86f31f1276c0a2011`, path
`src/watershed/abiss/abiss_watershed.wasm`, matching the earlier baseline hash.
Corrected reports use delivery-local `previous_abiss_watershed.wasm`; all 128
old/new/native disabled cases were rerun and pass. The verifier now rejects
identical old/new content hashes, even when paths differ.

SHA-256:
- Final (87,429 bytes): `fb8c6031c5d5fb5b826e32522a7c391364079c9f628ef53cc79b5b91d6174bba`
- Previous (55,719 bytes): `39ee6d816fe53b4396ed5ba73ff36e719117a087a68d5eeaddbb6bb08d772c2b`

## Reproduce from extracted source-bundle root

Layout here is `./abiss`, `./third_party/boost`, and delivery tools at root.
Put the previous binary, with the hash above, at the explicit `/tmp` path.
Node uses only built-in modules; native build uses g++ and vendored headers.

```sh
node generate_fixtures.cjs --check
# Full run: currently exits 1 for the documented 1/128 exact-ID discrepancy.
node verify_delivery.cjs --source ./abiss \
  --old /tmp/abiss-watershed-before-agglomeration.wasm \
  --report /tmp/abiss-delivery-extended-results.json
# Explicitly scoped required-suite run; NOT a full enabled-random parity claim.
node verify_delivery.cjs --source ./abiss \
  --old /tmp/abiss-watershed-before-agglomeration.wasm \
  --skip-enabled-random --report /tmp/abiss-delivery-required-results.json
# Bounded failure replay; outputs raw labels and canonical partitions for 5 runs.
g++ -std=c++17 -O2 -I ./abiss/src -I ./third_party/boost \
  native_runner.cpp ./abiss/src/ws/wasm.cpp -o /tmp/abiss-repro-native
node repro_case120.cjs /tmp/abiss-repro-native ./abiss_watershed.wasm
```

These checks were executed in the original delivery layout with absolute
`--source /tmp/abiss-agglomeration-delivery.HloEtF/source/abiss`,
`--old /tmp/abiss-agglomeration-delivery.HloEtF/previous_abiss_watershed.wasm`,
and root `extended-results.json` / `verification-results.json` report paths.
The extracted-layout commands above are their portable equivalents.

## Oracle and raw runner format

Fixtures are `{name,dims,affinities,high,low,size,dust,agg_threshold,labels}`;
`null` disables, **0 enables**. All arrays are x-fastest, channels slowest,
negative-neighbor affinities. The generator loads no kernel. Watershed scans
Z/Y/X with X innermost: internally connected low-coordinate slab seeds precede
the other slab, proving IDs 1/2; the dynamic A/B/C components seed IDs 1/2/3.
The single-pair merge keeps endpoint 1. Dynamic shared contacts recompute
`(.6+.6+0+.8+.8)/5 = .56`, not an unweighted edge mean or maximum. Dust and
background analytic cases remain all zero. See generator comments for proof.

Native stdin/file protocol is little-endian: magic `ABISSC01` (8 bytes),
X/Y/Z (3*u32), HIGH/LOW (2*f32), SIZE/DUST (2*u32), enabled (u32 0/1),
agg (f32), then 3*X*Y*Z float32 affinities. Header is 44 bytes; stdout is exactly
X*Y*Z uint32 labels. Failure uses stderr and nonzero exit. No JSON dependency.
