# Abiss
Affinity based image segmentation system, implementing algorithm described in https://arxiv.org/abs/2106.10795

# Build
```sh
mkdir build && cd build
cmake ..
make
```

## Single complete-chunk watershed

The header-only `abiss_watershed` CMake target exposes `ws/single_chunk.hpp`.
It requires C++17 and Boost headers, but not Boost I/O libraries, OpenMP, TBB,
Abseil, or a native allocator. To build and test only this path:

```sh
cmake -S . -B build-watershed -DABISS_BUILD_NATIVE_TOOLS=OFF
cmake --build build-watershed
ctest --test-dir build-watershed --output-on-failure
```

```cpp
#include <ws/single_chunk.hpp>

// affinities contains X * Y * Z * 3 float32 values.
std::vector<uint32_t> labels = abiss::watershed_chunk(
    affinities.data(), X, Y, Z,
    0.99999f,  // HIGH: include all edges at or above this affinity
    0.00005f, // LOW: activity and size-merge cutoff (strictly greater)
    50,       // SIZE: merge a region smaller than this many voxels
    50);      // DUST: remove surviving regions smaller than this many voxels
```

All four thresholds are optional, with the defaults shown above. SIZE and DUST
are independent: zero disables the corresponding merge/filter operation.
Merges use maximum contact affinities; SIZE is not a guaranteed minimum output
region size when no contact exceeds LOW.

Input is unpadded, x-fastest, channel-slowest `(X,Y,Z,3)` data; index
`x + X * (y + Y * (z + Z * channel))`. Channels 0/1/2 connect to the negative
x/y/z neighbor. All six faces are real boundaries, so outward edges are ignored.
The input buffer is unchanged; padding is handled internally. Output is an
unpadded, x-fastest `(X,Y,Z)` chunk of compact `uint32_t` supervoxel labels,
with zero for background/dust and no global ID offset.

Dimensions must be nonzero and fit the internal indexing/label limits. Affinities
must be finite and in `[0,1]`; thresholds must satisfy `0 <= LOW < HIGH <= 1`.
Invalid inputs throw `std::invalid_argument`; callers must provide the full input
buffer. The core does no file I/O or console logging. The existing
`examples/ws_single_chunk.hpp` API forwards to this implementation.

## Optional single-chunk agglomeration

The same C++17, Boost-header-only target also exposes:

```cpp
#include <ws/agg_single_chunk.hpp>

// Omit agg_threshold (or pass std::nullopt) for identical watershed-only output.
auto supervoxels = abiss::watershed_agglomerate_chunk(affinities.data(), X, Y, Z);
auto segments = abiss::watershed_agglomerate_chunk(
    affinities.data(), X, Y, Z, 0.99999f, 0.00005f, 50, 50,
    0.15f); // agg_threshold: explicitly enable agglomeration
```

`agg_threshold` must be finite and in `[0,1]`. Zero **enables** agglomeration;
only omission/`std::nullopt` disables it. Lower thresholds generally produce
larger segments. Watershed SIZE/DUST processing is unchanged and happens first.

Agglomeration recollects every contact from the final watershed labels and the
original affinities, including weak and zero-affinity contacts. It uses the
shared native `agglomerate_cc` kernel: contacts merge strictly above
`agg_threshold`, and shared-neighbor weights update by adding affinity sums and
contact areas (not maxima or unweighted means). The native size heuristic is
retained: a contact with mean affinity <= 0.35 is rejected when both regions
exceed 1,000,000 voxels and their combined size exceeds 10,000,000 voxels.

Output retains surviving watershed IDs and background zero; IDs are not
recompacted after agglomeration. Both inputs remain unchanged, and the core does
no file I/O or console logging. For existing label volumes, include
`agg/single_chunk.hpp` and call
`abiss::agglomerate_chunk(affinities, labels, X, Y, Z, agg_threshold)` directly.
`abiss::collect_region_graph` exposes the single-use in-memory graph for callers
of `agglomerate_cc`. The example APIs forward to these implementations, retaining
the demos' enabled-by-default threshold of 0.15.

## Standalone WebAssembly

With Emscripten and Boost headers available:

```sh
emcmake cmake -S . -B build-wasm -DABISS_BUILD_NATIVE_TOOLS=OFF \
    -DABISS_BUILD_WASM=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build-wasm
ctest --test-dir build-wasm --output-on-failure # Node.js
```

This produces `build-wasm/abiss_watershed.wasm`, with memory growth and WASM
exceptions enabled and no filesystem. If Boost is outside the toolchain search
path, set `-DBoost_NO_BOOST_CMAKE=ON` and
`-DBoost_INCLUDE_DIR=/path/containing/boost`; use a directory containing only Boost
headers rather than adding host system headers to Emscripten's path.

The C ABI is declared in `src/ws/wasm.h`. Existing `abiss_watershed` callers are
unchanged and continue to receive watershed-only output. The additional export
`abiss_watershed_agglomerate` takes the same arguments with a `float agg_threshold`
inserted after `dust_threshold` and before the output pointer/count. Use this
export to enable agglomeration; zero is valid, not a disable sentinel. Both
functions use element counts (not bytes), return 0 on success, 1 for invalid
input, 2 for allocation failure, and 3 for other errors. Output labels are written
only on success. `abiss_watershed_last_error()` returns the shared error string,
cleared on the next successful call. `malloc`, `free`, and memory are exported
for caller-managed buffers; refresh typed-array views after possible memory
growth. The standalone reactor imports only
`env.emscripten_notify_memory_growth`; no WASI runtime is required. Call its
`_initialize()` export exactly once before other exports (see
`tests/test_wasm_single_chunk.cjs`).
