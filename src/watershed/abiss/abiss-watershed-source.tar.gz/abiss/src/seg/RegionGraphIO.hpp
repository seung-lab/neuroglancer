#ifndef REGION_GRAPH_IO_HPP
#define REGION_GRAPH_IO_HPP

#include "Utils.hpp"
#include <algorithm>
#include <cassert>
#include <cstddef>
#include <execution>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

template<typename Ts, typename Ta>
struct __attribute__((packed)) SimpleEdge{
    Ts s1;
    Ts s2;
    Ta affinity;
    size_t area;
    explicit constexpr SimpleEdge(Ts v1 = 0 , Ts v2 = 0, Ta a = 0.0, size_t b = 0)
        :s1(v1), s2(v2), affinity(a),area(b) {};
};

template<typename Ts, typename Ta>
std::vector<SimpleEdge<Ts, Ta> > loadRegionGraph(const std::string & fileName)
{
    std::vector<SimpleEdge<Ts, Ta> > output_rg;
    auto input_rg = read_array<SimpleEdge<Ts, Ta> >(fileName);
    std::cout << "loading: " << fileName << std::endl;
    std::for_each(std::execution::par, input_rg.begin(), input_rg.end(), [](auto & a) {
        if (a.s1 < a.s2) {
            auto tmp = a.s1;
            a.s1 = a.s2;
            a.s2 = tmp;
        }
    });

    std::sort(std::execution::par, input_rg.begin(), input_rg.end(), [](const auto & a, const auto & b) {
        return ((a.s1 < b.s1) || (a.s1 == b.s1 && a.s2 < b.s2));
    });

    SimpleEdge<Ts, Ta> current_edge;
    for(const auto & e : input_rg) {
        if (current_edge.s1 != e.s1 || current_edge.s2 != e.s2) {
            if (current_edge.s1 != Ts(0) && current_edge.s2 != Ts(0)) {
                output_rg.push_back(current_edge);
            }
            current_edge = e;
        } else {
            current_edge.affinity += e.affinity;
            current_edge.area += e.area;
        }
    }

    if (current_edge.s1 != Ts(0) && current_edge.s2 != Ts(0)) {
        output_rg.push_back(current_edge);
    }

    return output_rg;
}

template <typename Ts, typename Ta>
void writeRegionGraph(const SetContainer<Ts> & incompleteSegments, const std::vector<SimpleEdge<Ts, Ta> >  rg, const std::string & incompleteFileName, const std::string & completeFileName)
{
    std::ofstream incomplete(incompleteFileName, std::ios_base::binary);
    std::ofstream complete(completeFileName, std::ios_base::binary);

    for (const auto &e : rg) {
        if (incompleteSegments.count(e.s1) > 0 && incompleteSegments.count(e.s2) > 0) {
            incomplete.write(reinterpret_cast<const char *>(&(e)), sizeof(e));
        } else {
            complete.write(reinterpret_cast<const char *>(&(e)), sizeof(e));
#ifdef MST_EDGE
            complete.write(reinterpret_cast<const char *>(&(e)), sizeof(e));
#endif
        }
    }
    assert(!incomplete.bad());
    assert(!complete.bad());
    incomplete.close();
    complete.close();
}

template <typename Ts, typename Ta>
void updateRegionGraph(const SetContainer<Ts> & incompleteSegments, const std::string & inputFileName, const std::string & incompleteFileName, const std::string & completeFileName)
{
    writeRegionGraph<Ts, Ta>(incompleteSegments, loadRegionGraph<Ts, Ta>(inputFileName), incompleteFileName, completeFileName);
}

#endif
