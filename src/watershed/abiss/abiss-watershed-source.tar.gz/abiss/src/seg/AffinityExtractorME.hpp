#ifndef AFFINITY_EXTRACTOR_ME_HPP
#define AFFINITY_EXTRACTOR_ME_HPP

#include "Types.h"
#include <algorithm>
#include <cassert>
#include <cstddef>
#include <fstream>
#include <string>
#include <utility>
#include <vector>

template<typename Ts, typename Ta, typename Chunk>
class AffinityExtractorME
{
public:
    AffinityExtractorME(const Chunk & aff)
        :m_aff(aff), m_edges() {}

    void collectVoxel(Coord & c, Ts segid) {}

    void collectBoundary(int face, Coord & c, Ts segid) {}

    void collectContactingSurface(int nv, Coord & c, Ts segid1, Ts segid2)
    {
        auto p = std::minmax(segid1, segid2);
        m_edges[p].first += m_aff[c[0]][c[1]][c[2]][nv];
        m_edges[p].second += 1;
    }

    void writeEdge(std::ofstream & out, const std::pair<Ts, Ts> & k, const std::pair<Ta, size_t> & v) {
        out.write(reinterpret_cast<const char *>(&(k.first)), sizeof(Ts));
        out.write(reinterpret_cast<const char *>(&(k.second)), sizeof(Ts));
        out.write(reinterpret_cast<const char *>(&(v.first)), sizeof(Ta));
        out.write(reinterpret_cast<const char *>(&(v.second)), sizeof(size_t));
    }

    void output(const SetContainer<Ts> & incompleteSegments, const MapContainer<Ts, Ts> & chunkMap, const std::string & completeFileName, const std::string & incompleteFileName)
    {
        std::vector<SegPair<Ts> > incomplete_segpairs;
        std::vector<SegPair<Ts> > complete_segpairs;

        std::ofstream complete(completeFileName, std::ios_base::binary);
        std::ofstream incomplete(incompleteFileName, std::ios_base::binary);

        std::vector<std::pair<Ta, Ts> > me_complete;
        std::vector<std::pair<Ta, Ts> > me_incomplete;
        MapContainer<SegPair<Ts>, std::pair<Ta, size_t>, HashFunction<SegPair<Ts> > > real_edges;
        for (const auto & kv : m_edges) {
            auto k = kv.first;
            auto v = kv.second;
            if (chunkMap.count(k.first) > 0) {
                k.first = chunkMap.at(k.first);
            }

            if (chunkMap.count(k.second) > 0) {
                k.second = chunkMap.at(k.second);
            }
            if (k.first == k.second) {
                continue;
            }
            auto p = std::minmax(k.first, k.second);
            real_edges[p].first += v.first;
            real_edges[p].second += v.second;
        }

        for (const auto & [k,v] : real_edges) {

            if (incompleteSegments.count(k.first) > 0 && incompleteSegments.count(k.second) > 0) {
                incomplete_segpairs.push_back(k);
                me_incomplete.push_back(v);
            } else {
                complete_segpairs.push_back(k);
                me_complete.push_back(v);
            }
        }

        for (size_t i = 0; i != complete_segpairs.size(); i++) {
            const auto & p = complete_segpairs[i];
            writeEdge(complete, p, me_complete[i]);
#ifdef MST_EDGE
            writeEdge(complete, p, me_complete[i]);
#endif
        }
        for (size_t i = 0; i != incomplete_segpairs.size(); i++) {
            const auto & p = incomplete_segpairs[i];
            writeEdge(incomplete, p, me_incomplete[i]);
        }
        assert(!incomplete.bad());
        assert(!complete.bad());
        incomplete.close();
        complete.close();
    }

    const MapContainer<SegPair<Ts>, std::pair<Ta, size_t>, HashFunction<SegPair<Ts> > > & edges() const {return m_edges;}

private:
    const Chunk & m_aff;
    MapContainer<SegPair<Ts>, std::pair<Ta, size_t>, HashFunction<SegPair<Ts> > > m_edges;
};

#endif
