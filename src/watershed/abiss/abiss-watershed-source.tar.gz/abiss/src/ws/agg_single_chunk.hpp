#pragma once

#include <optional>

#include "single_chunk.hpp"
#include "../agg/single_chunk.hpp"

namespace abiss {

// Disabled by default: return the exact watershed labels without collecting a graph.
// An explicit agg_threshold (including zero) enables mean-affinity agglomeration.
inline std::vector<uint32_t> watershed_agglomerate_chunk(
    const float* affinities, std::size_t xdim, std::size_t ydim, std::size_t zdim,
    float high_threshold = 0.99999f, float low_threshold = 0.00005f,
    std::size_t size_threshold = 50, std::size_t dust_threshold = 50,
    std::optional<float> agg_threshold = std::nullopt)
{
    if (agg_threshold && !(0 <= *agg_threshold && *agg_threshold <= 1)) {
        throw std::invalid_argument("agglomeration threshold must be finite and in [0, 1]");
    }
    auto labels = watershed_chunk(
        affinities, xdim, ydim, zdim,
        high_threshold, low_threshold, size_threshold, dust_threshold);
    if (agg_threshold) {
        return agglomerate_chunk(
            affinities, labels.data(), xdim, ydim, zdim, *agg_threshold);
    }
    return labels;
}

} // namespace abiss
