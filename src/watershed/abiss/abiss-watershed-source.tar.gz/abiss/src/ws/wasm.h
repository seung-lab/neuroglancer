// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// Counts are elements, not bytes. Buffers must be valid, distinct caller allocations.
// Returns 0 on success, 1 for invalid input, 2 for allocation failure, 3 otherwise.
// Labels are written only on success. Options are explicit; see ws/single_chunk.hpp.
int abiss_watershed(const float* affinities, uint32_t affinity_count,
                    uint32_t xdim, uint32_t ydim, uint32_t zdim,
                    float high_threshold, float low_threshold,
                    uint32_t size_threshold, uint32_t dust_threshold,
                    uint32_t* labels, uint32_t label_count);

// The same watershed, followed by mean-affinity agglomeration at agg_threshold.
// agg_threshold must be finite and in [0,1]; zero enables merging, not a disable flag.
// Use abiss_watershed instead to disable agglomeration (its ABI is unchanged).
int abiss_watershed_agglomerate(const float* affinities, uint32_t affinity_count,
                               uint32_t xdim, uint32_t ydim, uint32_t zdim,
                               float high_threshold, float low_threshold,
                               uint32_t size_threshold, uint32_t dust_threshold,
                               float agg_threshold, uint32_t* labels, uint32_t label_count);

// Shared error string, valid until the next segmentation call; empty on success.
const char* abiss_watershed_last_error(void);

#ifdef __cplusplus
} // extern "C"
#endif
