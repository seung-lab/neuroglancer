// SPDX-License-Identifier: GPL-3.0-or-later

#include "agg_single_chunk.hpp"
#include "wasm.h"

#include <cstring>
#include <new>

namespace {

char last_error[256] = {};

int fail(int status, const char* message)
{
    std::strncpy(last_error, message, sizeof(last_error) - 1);
    last_error[sizeof(last_error) - 1] = '\0';
    return status;
}

int segment_chunk(const float* affinities, uint32_t affinity_count,
                  uint32_t xdim, uint32_t ydim, uint32_t zdim,
                  float high_threshold, float low_threshold,
                  uint32_t size_threshold, uint32_t dust_threshold,
                  std::optional<float> agg_threshold,
                  uint32_t* labels, uint32_t label_count)
{
    last_error[0] = '\0';
    try {
        const auto voxel_count = abiss::chunk_voxel_count(xdim, ydim, zdim);
        if (affinity_count != 3 * voxel_count || label_count != voxel_count) {
            return fail(1, "buffer lengths must match the chunk dimensions");
        }
        if (labels == nullptr) {
            return fail(1, "label buffer must not be null");
        }
        const auto result = abiss::watershed_agglomerate_chunk(
            affinities, xdim, ydim, zdim, high_threshold, low_threshold,
            size_threshold, dust_threshold, agg_threshold);
        std::copy(result.begin(), result.end(), labels);
        return 0;
    } catch (const std::invalid_argument& error) {
        return fail(1, error.what());
    } catch (const std::bad_alloc&) {
        return fail(2, "watershed allocation failed");
    } catch (const std::exception& error) {
        return fail(3, error.what());
    } catch (...) {
        return fail(3, "unknown watershed error");
    }
}

} // namespace

extern "C" {

int abiss_watershed(const float* affinities, uint32_t affinity_count,
                    uint32_t xdim, uint32_t ydim, uint32_t zdim,
                    float high_threshold, float low_threshold,
                    uint32_t size_threshold, uint32_t dust_threshold,
                    uint32_t* labels, uint32_t label_count)
{
    return segment_chunk(affinities, affinity_count, xdim, ydim, zdim,
                         high_threshold, low_threshold, size_threshold, dust_threshold,
                         std::nullopt, labels, label_count);
}

int abiss_watershed_agglomerate(const float* affinities, uint32_t affinity_count,
                               uint32_t xdim, uint32_t ydim, uint32_t zdim,
                               float high_threshold, float low_threshold,
                               uint32_t size_threshold, uint32_t dust_threshold,
                               float agg_threshold, uint32_t* labels, uint32_t label_count)
{
    return segment_chunk(affinities, affinity_count, xdim, ydim, zdim,
                         high_threshold, low_threshold, size_threshold, dust_threshold,
                         agg_threshold, labels, label_count);
}

const char* abiss_watershed_last_error()
{
    return last_error;
}

} // extern "C"
