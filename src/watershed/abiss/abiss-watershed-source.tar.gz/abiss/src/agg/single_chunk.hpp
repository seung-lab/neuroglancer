#pragma once

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <numeric>
#include <stdexcept>
#include <vector>

#include "agglomeration.hpp"
#include "../seg/AffinityExtractorME.hpp"
#include "../seg/TraverseSegments.hpp"

namespace abiss {

inline std::size_t agglomeration_voxel_count(
    std::size_t xdim, std::size_t ydim, std::size_t zdim)
{
    const auto limit = std::numeric_limits<std::ptrdiff_t>::max() / (3 * sizeof(float));
    std::size_t count = 1;
    for (auto dim : {xdim, ydim, zdim}) {
        if (dim == 0 || dim > static_cast<std::size_t>(std::numeric_limits<int>::max())
            || count > limit / dim) {
            throw std::invalid_argument("chunk dimensions are empty or too large");
        }
        count *= dim;
    }
    return count;
}

// Edges use dense indices into seg_indices; retain every contact's sum and area.
// All six boundaries are real: no halo, overlap skipping, or frozen segments.
// The returned graph is single-use: agglomerate_cc mutates it and its heap handles.
inline agglomeration_data_t<mean_edge, mean_edge_greater> collect_region_graph(
    const float* affinities, const uint32_t* labels,
    std::size_t xdim, std::size_t ydim, std::size_t zdim)
{
    const auto count = agglomeration_voxel_count(xdim, ydim, zdim);
    if (affinities == nullptr || labels == nullptr) {
        throw std::invalid_argument("affinity and label buffers must not be null");
    }
    for (std::size_t i = 0; i < count * 3; ++i) {
        if (!std::isfinite(affinities[i]) || affinities[i] < 0 || affinities[i] > 1) {
            throw std::invalid_argument("affinities must be finite values in [0, 1]");
        }
    }

    agglomeration_data_t<mean_edge, mean_edge_greater> graph{};
    MapContainer<uint32_t, std::size_t> counts;
    for (std::size_t i = 0; i < count; ++i) {
        if (labels[i] != 0) {
            ++counts[labels[i]];
        }
    }
    for (const auto& entry : counts) {
        graph.seg_indices.push_back(entry.first);
    }
    std::sort(graph.seg_indices.begin(), graph.seg_indices.end());
    MapContainer<uint32_t, seg_t> indices;
    for (std::size_t i = 0; i < graph.seg_indices.size(); ++i) {
        const auto id = static_cast<uint32_t>(graph.seg_indices[i]);
        indices.emplace(id, i);
        graph.seg_size.push_back(counts.at(id));
    }
    graph.supervoxel_counts.assign(graph.seg_indices.size(), 1);
    graph.incident.resize(graph.seg_indices.size());

    using AffinityChunk = ConstChunkRef<float, 4>;
    const AffinityChunk aff(affinities, boost::extents[xdim][ydim][zdim][3],
                            boost::fortran_storage_order());
    const ConstChunkRef<uint32_t, 3> seg(labels, boost::extents[xdim][ydim][zdim],
                                        boost::fortran_storage_order());
    AffinityExtractorME<uint32_t, float, AffinityChunk> extractor(aff);
    traverseSegments<0>(seg, extractor);
    for (const auto& [pair, weight] : extractor.edges()) {
        graph.rg_vector.push_back({indices.at(pair.first), indices.at(pair.second),
                                   mean_edge(weight.first, weight.second)});
    }
    std::sort(graph.rg_vector.begin(), graph.rg_vector.end(), [](const auto& a, const auto& b) {
        return a.v0 < b.v0 || (a.v0 == b.v0 && a.v1 < b.v1);
    });
    return graph;
}

// Unpadded float32 (X,Y,Z,3) affinities and uint32 (X,Y,Z) labels,
// x fastest, channel slowest; channels point to negative x/y/z neighbors.
// Output retains surviving input IDs and label 0; neither input is modified.
// Merge contacts strictly above agg_threshold, with the native size heuristic.
inline std::vector<uint32_t> agglomerate_chunk(
    const float* affinities, const uint32_t* labels,
    std::size_t xdim, std::size_t ydim, std::size_t zdim,
    float agg_threshold = 0.15f)
{
    if (!(0 <= agg_threshold && agg_threshold <= 1)) {
        throw std::invalid_argument("agglomeration threshold must be finite and in [0, 1]");
    }
    auto graph = collect_region_graph(affinities, labels, xdim, ydim, zdim);
    graph.params.input_aff_threshold = agg_threshold;
    auto merged = agglomerate_cc<mean_edge, mean_edge_greater, mean_edge_plus, mean_edge_limits>(
        graph, 0, graph.rg_vector.size(), mean_edge(agg_threshold, 1));

    std::vector<seg_t> parent(graph.seg_indices.size());
    std::iota(parent.begin(), parent.end(), seg_t(0));
    for (const auto& [from, to] : merged.remap) {
        parent[from] = to;
    }
    MapContainer<uint32_t, uint32_t> remap;
    for (std::size_t i = 0; i < parent.size(); ++i) {
        auto root = parent[i];
        while (root != parent[root]) {
            root = parent[root];
        }
        auto current = static_cast<seg_t>(i);
        while (current != root) {
            const auto next = parent[current];
            parent[current] = root;
            current = next;
        }
        remap.emplace(static_cast<uint32_t>(graph.seg_indices[i]),
                      static_cast<uint32_t>(graph.seg_indices[root]));
    }
    const auto count = agglomeration_voxel_count(xdim, ydim, zdim);
    std::vector<uint32_t> result(count, 0);
    for (std::size_t i = 0; i < count; ++i) {
        if (labels[i] != 0) {
            result[i] = remap.at(labels[i]);
        }
    }
    return result;
}

} // namespace abiss
