//
// Copyright (C) 2013-2016  Aleksandar Zlateski <zlateski@mit.edu>
// Copyright (C) 2016-present  Ran Lu <ranl@princeton.edu>
// ------------------------------------------------------------------
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

#pragma once

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <functional>
#include <iterator>
#include <limits>
#include <numeric>
#include <ostream>
#include <type_traits>
#include <utility>
#include <vector>

#include <boost/heap/fibonacci_heap.hpp>

#include "../seg/Types.h"
#include "edges.h"

static const size_t frozen = (1UL<<(std::numeric_limits<std::size_t>::digits-2));

inline bool is_frozen(size_t size) {
    return size & frozen;
}

template <class Neighbors, class Counts>
bool frozen_neighbors(const Neighbors & neighbors, const Counts & supervoxel_counts)
{
    for (auto & [k, v] : neighbors) {
        if (is_frozen(supervoxel_counts[k])) {
            return true;
        }
    }
    return false;
}

template <class T, class C = std::greater<T>>
struct heapable_edge;

template <class T, class C = std::greater<T>>
struct heapable_edge_compare
{
    bool operator()(heapable_edge<T, C> const & a,
                    heapable_edge<T, C> const & b) const
    {
        C c;
        return c(b.edge->w, a.edge->w);
    }
};

template <class T, class C = std::greater<T>>
using heap_type = boost::heap::fibonacci_heap<
    heapable_edge<T, C>, boost::heap::compare<heapable_edge_compare<T, C>>>;

template <class T, class C = std::greater<T>>
using heap_handle_type = typename heap_type<T, C>::handle_type;

template <class T, class C>
struct __attribute__((packed)) heapable_edge
{
    edge_t<T> * edge;
    explicit constexpr heapable_edge(edge_t<T> * e)
        : edge(e) {};
};

template <class T, class C>
struct handle_wrapper
{
    edge_t<T> * edge;
    heap_handle_type<T, C> handle;

    explicit constexpr handle_wrapper(edge_t<T> * e, heap_handle_type<T, C> & h)
        : handle(h) {
            edge = e;
        };
    [[nodiscard]] bool valid_handle() const { return handle != heap_handle_type<T, C>(); }
    [[nodiscard]] seg_t segid(const seg_t exclude) const {
        return exclude == edge->v0 ? edge->v1 : edge->v0;
    }
};

struct agglomeration_size_heuristic_t
{
    aff_t aff_threshold = 0.35;
    size_t small_voxel_threshold = 1'000'000;
    size_t large_voxel_threshold = 10'000'000;
};

struct agglomeration_semantic_heuristic_t
{
    aff_t aff_threshold = 0.5;
    size_t total_signal_threshold = 100'000;
    double dominant_signal_ratio = 0.6;
};

struct agglomeration_twig_heuristic_t
{
    aff_t aff_threshold_delta = 0;
    size_t voxel_threshold = 100'000;
    size_t area_threshold = 50;
};

struct agglomeration_param_t
{
    agglomeration_size_heuristic_t size_params;
    agglomeration_semantic_heuristic_t sem_params;
    agglomeration_twig_heuristic_t twig_params;
    aff_t input_aff_threshold;
    aff_t heuristics_aff_threshold = size_params.aff_threshold > sem_params.aff_threshold ? size_params.aff_threshold : sem_params.aff_threshold;
    aff_t starting_aff_threshold = 0.9;
    aff_t agglomeration_step = 0.101;
    size_t optimal_number_of_partitions = 1;
    size_t minimal_number_of_edges = 100'000;
};

// Mutable, single-use graph storage for agglomerate_cc: incident entries contain
// handles owned by its local heap and must be discarded before reusing the data.
// The edge vector must remain stable while that heap is alive.
template <class T, class Compare = std::greater<T> >
struct agglomeration_data_t
{
    std::vector<MapContainer<seg_t, handle_wrapper<T, Compare> > > incident;
    std::vector<edge_t<T> > rg_vector;
    std::vector<size_t> supervoxel_counts;
    std::vector<seg_t> seg_indices;
    std::vector<sem_array_t> sem_counts;
    std::vector<size_t> seg_size;
    agglomeration_param_t params;
};

template <class T>
struct agglomeration_output_t
{
    std::vector<edge_t<T> > res_rg_vector;
    std::vector<edge_t<T> > rej_rg_vector;
    std::vector<edge_t<T> > sem_rg_vector;
    std::vector<edge_t<T> > merged_rg_vector;
    std::vector<edge_t<T> > twig_rg_vector;
    std::vector<std::pair<seg_t, seg_t> > remap;
};

template <class T, class Compare = std::greater<T>, class Progress = std::nullptr_t>
inline heap_type<T, Compare> populate_heap(agglomeration_data_t<T, Compare> & agg_data, size_t startpos, size_t endpos, T const & threshold, Progress progress = nullptr)
{
    Compare comp;
    heap_type<T, Compare> heap;
    auto & incident = agg_data.incident;
    auto & supervoxel_counts = agg_data.supervoxel_counts;
    auto & rg_vector = agg_data.rg_vector;
    auto & seg_indices = agg_data.seg_indices;

    size_t i = 0;

    for (size_t j = startpos; j != endpos; j++) {
        auto & e = rg_vector[j];
        heap_handle_type<T, Compare> handle;
        if (comp(e.w, threshold)){
            handle = heap.emplace(& e);
        }
        auto v0 = e.v0;
        auto v1 = e.v1;
        incident[e.v0].emplace(v1,handle_wrapper<T, Compare>(&e, handle));
        incident[e.v1].emplace(v0,handle_wrapper<T, Compare>(&e, handle));
        i++;
        if constexpr (!std::is_same_v<Progress, std::nullptr_t>) {
            if (progress && i % 10'000'000 == 0) {
                *progress << "reading " << i << "th edge" << std::endl;
            }
        }
    }

    return heap;
}

inline std::pair<size_t, size_t> sem_label(const sem_array_t & labels)
{
    const auto *label = std::max_element(labels.begin(), labels.end());
    return std::make_pair(std::distance(labels.begin(), label), (*label));
}

inline bool sem_can_merge(const sem_array_t & labels1, const sem_array_t & labels2, const agglomeration_semantic_heuristic_t & sem_params)
{
    auto max_label1 = std::distance(labels1.begin(), std::max_element(labels1.begin(), labels1.end()));
    auto max_label2 = std::distance(labels2.begin(), std::max_element(labels2.begin(), labels2.end()));
    auto total_label1 = std::accumulate(labels1.begin(), labels1.end(), static_cast<size_t>(0));
    auto total_label2 = std::accumulate(labels2.begin(), labels2.end(), static_cast<size_t>(0));
    if (labels1[max_label1] < sem_params.dominant_signal_ratio * total_label1 || total_label1 < sem_params.total_signal_threshold) { //unsure about the semantic label
        return true;
    }
    if (labels2[max_label2] < sem_params.dominant_signal_ratio * total_label2 || total_label2 < sem_params.total_signal_threshold) { //unsure about the semantic label
        return true;
    }
    if (max_label1 == max_label2) {
        return true;
    }
    return false;
}

template <class T, class Compare = std::greater<T>, class Plus = std::plus<T>,
          class Limits = std::numeric_limits<T>, class Progress = std::nullptr_t>
inline agglomeration_output_t<T> agglomerate_cc(agglomeration_data_t<T, Compare> & agg_data, size_t startpos, size_t endpos, T const target_threshold, Progress progress = nullptr)
{
    Compare comp;
    Plus    plus;

    T const h_threshold = T(agg_data.params.heuristics_aff_threshold,1);
    T const size_aff_threshold = T(agg_data.params.size_params.aff_threshold, 1);
    T const sem_aff_threshold = T(agg_data.params.sem_params.aff_threshold, 1);
    T const backbone_threshold = T(agg_data.params.input_aff_threshold, 1);
    const auto twig_params = agg_data.params.twig_params;
    const auto size_params = agg_data.params.size_params;
    const auto sem_params = agg_data.params.sem_params;

    auto & supervoxel_counts = agg_data.supervoxel_counts;
    auto & seg_indices = agg_data.seg_indices;
    auto & sem_counts = agg_data.sem_counts;
    auto & seg_size = agg_data.seg_size;
    auto & rg_vector = agg_data.rg_vector;
    agglomeration_output_t<T> output;
    auto heap= populate_heap<T, Compare>(agg_data, startpos, endpos, target_threshold, progress);
    auto & incident = agg_data.incident;
    auto heap_size = heap.size();
    size_t num_of_edges = 0;
    while (!heap.empty() && comp(heap.top().edge->w, target_threshold))
    {
        num_of_edges += 1;
        auto e = heap.top();
        auto v0 = e.edge->v0;
        auto v1 = e.edge->v1;

        incident[v0].erase(v1);
        incident[v1].erase(v0);
        heap.pop();


        if (v0 != v1)
        {

            auto s = v0;
#ifdef EXTRA
            if ((is_frozen(supervoxel_counts[v0]) && is_frozen(supervoxel_counts[v1]))
                || (is_frozen(supervoxel_counts[v0]) && (frozen_neighbors(incident[v1], supervoxel_counts, v1) || (!comp(e.edge->w, h_threshold) && (!sem_counts.empty() || seg_size[v1] > size_params.small_voxel_threshold))))
                || (is_frozen(supervoxel_counts[v1]) && (frozen_neighbors(incident[v0], supervoxel_counts, v0) || (!comp(e.edge->w, h_threshold) && (!sem_counts.empty() || seg_size[v0] > size_params.small_voxel_threshold)))))
#else
            if ((is_frozen(supervoxel_counts[v0]) || is_frozen(supervoxel_counts[v1])))
#endif
            {
                supervoxel_counts[v0] |= frozen;
                supervoxel_counts[v1] |= frozen;
                output.res_rg_vector.push_back(*(e.edge));
                e.edge->w = Limits::min();
                continue;
            }

            if (!comp(e.edge->w, sem_aff_threshold)) {
                if (!sem_counts.empty()){
                    if (!sem_can_merge(sem_counts[v0],sem_counts[v1],sem_params)) {
                        output.sem_rg_vector.push_back(*(e.edge));
                        e.edge->w = Limits::min();
                        continue;
                    }
                }
            }

            if (!comp(e.edge->w, size_aff_threshold)) {
                size_t size0 = seg_size[v0];
                size_t size1 = seg_size[v1];
                auto p = std::minmax({size0, size1});
                if (p.first > size_params.small_voxel_threshold and (size0+size1) > size_params.large_voxel_threshold) {
                    output.rej_rg_vector.push_back(*(e.edge));
                    e.edge->w = Limits::min();
                    continue;
                }
            }

            if (!comp(e.edge->w, backbone_threshold)){
                size_t size0 = seg_size[v0];
                size_t size1 = seg_size[v1];
                auto p = std::minmax({size0, size1});
                if ((p.first > twig_params.voxel_threshold) or (e.edge->w.num > twig_params.area_threshold)) {
                    e.edge->w = Limits::min();
                    continue;
                }
                output.twig_rg_vector.push_back(*(e.edge));
            }
#ifdef FINAL
            if (incident[v0].size() < incident[v1].size()) {
                s = v1;
            }
#else
            if (supervoxel_counts[v0] < supervoxel_counts[v1]) {
                s = v1;
            }
#endif
            if (is_frozen(supervoxel_counts[v0])) {
                s = v0;
            } else if (is_frozen(supervoxel_counts[v1])) {
                s = v1;
            }

            //std::cout << "Join " << v0 << " and " << v1 << std::endl;
            supervoxel_counts[v0] += supervoxel_counts[v1];
            supervoxel_counts[v1] = 0;
            std::swap(supervoxel_counts[v0], supervoxel_counts[s]);

            seg_size[v0] += seg_size[v1];
            seg_size[v1] = 0;
            std::swap(seg_size[v0], seg_size[s]);

            if (!sem_counts.empty()) {
                std::transform(sem_counts[v0].begin(), sem_counts[v0].end(), sem_counts[v1].begin(), sem_counts[v0].begin(), std::plus<size_t>());
                sem_counts[v1] = sem_array_t();
                std::swap(sem_counts[v0], sem_counts[s]);
            }

            output.merged_rg_vector.push_back(*(e.edge));
            if (v0 == s) {
                output.remap.emplace_back(v1, s);
            } else if (v1 == s) {
                output.remap.emplace_back(v0, s);
            } else {
                if constexpr (!std::is_same_v<Progress, std::nullptr_t>) {
                    if (progress) {
                        *progress << "Something is wrong in the MST" << std::endl;
                        *progress << "s: " << s << ", v0: " << v0 << ", v1: " << v1 << std::endl;
                    }
                }
                std::abort();
            }

            if (s == v0)
            {
                std::swap(v0, v1);
            }

            // v0 is dissapearing from the graph

            // loop over other edges e0 = {v0,v}
            e.edge->w = Limits::min();
            for (auto p: incident[v0]) {
                auto v = p.first;
                auto e0 = p.second;
                if (v == v0) {
                    if constexpr (!std::is_same_v<Progress, std::nullptr_t>) {
                        if (progress) {
                            *progress << "loop in the incident matrix: " << seg_indices[v] << std::endl;
                        }
                    }
                    std::abort();
                }

                incident[v].erase(v0);

                //auto it = search_neighbors(incident[v1], v1, v);
                //if (it != std::end(incident[v1]) && (*it).segid(v1) == v)
                if (incident[v1].count(v) != 0)
                                                  // {v0,v} and {v1,v} exist, we
                                                  // need to merge them
                {
                    auto & e = incident[v1].at(v);
                    if(e0.edge->v0 == v0) {
                        e0.edge->v0 = v1;
                    }
                    if(e0.edge->v1 == v0) {
                        e0.edge->v1 = v1;
                    }
                    if (!e.valid_handle()) {
                        auto & e_dual = incident[v].at(v1);
                        std::swap(e0.edge, e.edge);
                        std::swap(e0.handle, e.handle);
                        e_dual.edge = e.edge;
                        e_dual.handle = e.handle;
                    }
                    e.edge->w=plus(e.edge->w, e0.edge->w);
                    e0.edge->w = Limits::min();
                    if (e.valid_handle()) {
                        heap.update(e.handle);
                        if (e0.valid_handle()) {
                            heap.erase(e0.handle);
                        }
                    }
                }
                else
                {
                    auto e = e0.edge;
                    if (e->v0 == v0) {
                        e->v0 = v1;
                    }
                    if (e->v1 == v0) {
                        e->v1 = v1;
                    }
                    incident[v].emplace(v1,e0);
                    incident[v1].emplace(v,e0);
                }
            }
            incident[v0].clear();
        }
    }
    return output;
}
