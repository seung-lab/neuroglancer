cmake_minimum_required(VERSION 3.8)
project(ABISS)
set(Boost_USE_STATIC_LIBS OFF)
set(Boost_USE_MULTITHREADED ON)
set(Boost_USE_STATIC_RUNTIME OFF)
set(optionalLibs)

option(ABISS_BUILD_NATIVE_TOOLS "Build the native file-based processing tools" ON)
option(ABISS_BUILD_WASM "Build the standalone watershed WebAssembly module" OFF)

if(ABISS_BUILD_WASM AND NOT EMSCRIPTEN)
    message(FATAL_ERROR "ABISS_BUILD_WASM requires the Emscripten toolchain (emcmake)")
endif()
if(ABISS_BUILD_WASM AND ABISS_BUILD_NATIVE_TOOLS)
    message(FATAL_ERROR "ABISS_BUILD_WASM requires ABISS_BUILD_NATIVE_TOOLS=OFF")
endif()

find_package(Boost REQUIRED)
add_library(abiss_watershed INTERFACE)
target_compile_features(abiss_watershed INTERFACE cxx_std_17)
target_include_directories(abiss_watershed INTERFACE
    ${CMAKE_CURRENT_SOURCE_DIR}/src
    ${Boost_INCLUDE_DIRS})

if(ABISS_BUILD_WASM)
    add_executable(abiss_watershed_wasm src/ws/wasm.cpp)
    target_link_libraries(abiss_watershed_wasm PRIVATE abiss_watershed)
    target_compile_options(abiss_watershed_wasm PRIVATE -fwasm-exceptions)
    set_target_properties(abiss_watershed_wasm PROPERTIES
        OUTPUT_NAME abiss_watershed
        SUFFIX .wasm
        LINK_FLAGS "-fwasm-exceptions --no-entry -sSTANDALONE_WASM=1 -sFILESYSTEM=0 -sALLOW_MEMORY_GROWTH=1 -sMAXIMUM_MEMORY=2147483648 -sEXPORTED_FUNCTIONS=_abiss_watershed,_abiss_watershed_agglomerate,_abiss_watershed_last_error,_malloc,_free")
endif()

include(CTest)
if(BUILD_TESTING)
    add_subdirectory(tests)
endif()

if(NOT ABISS_BUILD_NATIVE_TOOLS)
    return()
endif()

set(CMAKE_CXX_STANDARD 20)

set(CMAKE_CXX_FLAGS_RELEASE "${CMAKE_CXX_FLAGS} -O3 -fopenmp")
set(CMAKE_CXX_FLAGS_DEBUG "${CMAKE_CXX_FLAGS} -Og -g -fopenmp")

set(THREADS_PREFER_PTHREAD_FLAG ON)

find_package(Boost COMPONENTS iostreams system REQUIRED)
find_package(Threads REQUIRED)
find_package(OpenMP REQUIRED)
find_package(TBB REQUIRED)
find_package(absl)

if(CMAKE_BUILD_TYPE STREQUAL "Debug")
    set(absl_FOUND FALSE)
    message(STATUS "Debug mode: forcing std::unordered_map")
endif()

find_package(PkgConfig REQUIRED)
pkg_check_modules(JEMALLOC jemalloc)
pkg_check_modules(MIMALLOC mimalloc)


if(MIMALLOC_FOUND)
    add_definitions(-DUSE_MIMALLOC)
    include_directories(${MIMALLOC_INCLUDE_DIRS})
    set(optionalLibs ${optionalLibs} ${MIMALLOC_LDFLAGS})
    message(STATUS "Use mimalloc as the default allocator.")
elseif(JEMALLOC_FOUND)
    set(optionalLibs ${optionalLibs} ${JEMALLOC_LDFLAGS})
    message(STATUS "Use jemalloc as the default allocator.")
endif()

if(absl_FOUND)
    add_definitions(-DUSE_ABSL_HASHMAP)
    set(optionalLibs ${optionalLibs}
        absl::flat_hash_map
        absl::flat_hash_set
        )
    message(STATUS "Use abseil::flat_hash_map and absl::flat_hash_set")
endif(absl_FOUND)

link_libraries(TBB::tbb ${Boost_LIBRARIES} ${optionalLibs})

if(EXTRACT_SIZE)
    add_definitions(-DEXTRACT_SIZE)
endif(EXTRACT_SIZE)

if(EXTRACT_BBOX)
    add_definitions(-DEXTRACT_BBOX)
endif(EXTRACT_BBOX)

if(EXTRACT_COM)
    add_definitions(-DEXTRACT_COM)
endif(EXTRACT_COM)


if(MST_EDGE)
    add_definitions(-DMST_EDGE)
endif(MST_EDGE)

if(DOUBLE)
    add_definitions(-DDOUBLE)
endif(DOUBLE)

add_executable(meme
    src/seg/merge_edges_ME.cpp)
add_executable(acme
    src/seg/atomic_chunk_ME.cpp)
add_executable(assort
    src/seg/assort.cpp)
add_executable(split_remap
    src/seg/split_remap.cpp)
add_executable(match_chunks
    src/seg/match_chunks.cpp)
add_executable(reduce_chunk
    src/seg/reduce_chunk.cpp)
add_executable(size_map
    src/seg/size_map.cpp)
add_executable(evaluate
    src/seg/eval.cpp)
add_executable(ws
    src/ws/atomic_chunk.cpp)
add_executable(ws2
    src/ws/merge_chunks.cpp)
add_executable(ws3
    src/ws/remap.cpp)
add_executable(agg
    src/agg/mean_aggl.cpp)
add_executable(agg_nonoverlap
    src/agg/mean_aggl.cpp)
add_executable(agg_overlap
    src/agg/mean_aggl.cpp)
add_executable(agg_extra
    src/agg/mean_aggl.cpp)
add_executable(accs
    src/seg/contact_surface.cpp)
add_executable(mecs
    src/seg/merge_cs.cpp)
#target_compile_definitions(agg PRIVATE FINAL PRIVATE EXTRA)
#target_compile_definitions(agg_overlap PRIVATE OVERLAPPED PRIVATE FINAL PRIVATE EXTRA)
#target_compile_definitions(agg_extra PRIVATE EXTRA)
target_compile_definitions(agg PRIVATE FINAL)
target_compile_definitions(agg_overlap PRIVATE OVERLAPPED PRIVATE FINAL)

if(BUILD_TESTING)
    add_executable(test_affinity_region_graph tests/test_affinity_region_graph.cpp)
    add_test(NAME affinity_region_graph COMMAND test_affinity_region_graph)
    add_executable(test_affinity_region_graph_mst tests/test_affinity_region_graph.cpp)
    target_compile_definitions(test_affinity_region_graph_mst PRIVATE MST_EDGE)
    add_test(NAME affinity_region_graph_mst COMMAND test_affinity_region_graph_mst)
endif()
