#pragma once

#include "ws_single_chunk.hpp"
#include "agg_single_chunk.hpp"
#include "../src/ws/agg_single_chunk.hpp"

namespace abiss_demo {

// Input/output layout and real-boundary behavior match the individual demos.
// Keep watershed labels in memory and recollect mean contacts from the original affinities.
inline std::vector<uint32_t> watershed_agglomerate_chunk(
    const float* affinities, std::size_t xdim, std::size_t ydim, std::size_t zdim,
    float high_threshold = 0.99999f, float low_threshold = 0.00005f,
    std::size_t size_threshold = 50, std::size_t dust_threshold = 50,
    float agg_threshold = 0.15f)
{
    return abiss::watershed_agglomerate_chunk(
        affinities, xdim, ydim, zdim,
        high_threshold, low_threshold, size_threshold, dust_threshold, agg_threshold);
}

} // namespace abiss_demo
