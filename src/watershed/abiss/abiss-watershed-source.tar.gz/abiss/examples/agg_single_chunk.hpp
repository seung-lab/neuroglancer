#pragma once

#include "../src/agg/single_chunk.hpp"

namespace abiss_demo {

using abiss::agglomeration_voxel_count;
using abiss::collect_region_graph;
using abiss::agglomerate_chunk;

} // namespace abiss_demo
