#pragma once

#include "../src/ws/single_chunk.hpp"

namespace abiss_demo {

using abiss::chunk_voxel_count;
using abiss::watershed_chunk;

} // namespace abiss_demo
