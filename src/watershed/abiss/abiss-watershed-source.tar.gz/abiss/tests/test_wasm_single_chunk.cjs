// Run against the standalone module, not Emscripten-generated JavaScript.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const wasmModule = new WebAssembly.Module(fs.readFileSync(process.argv[2]));
assert.deepEqual(WebAssembly.Module.imports(wasmModule), [{
    module: 'env', name: 'emscripten_notify_memory_growth', kind: 'function',
}], 'standalone browser module must not require a WASI runtime');
const instance = new WebAssembly.Instance(wasmModule, {
    env: { emscripten_notify_memory_growth() {} },
});
const api = instance.exports;
api._initialize();
const count = 6 * 8 * 10;
const affPtr = api.malloc(count * 3 * 4);
const labelPtr = api.malloc(count * 4);
assert.ok(affPtr && labelPtr, 'allocation failed');
const labels = () => Array.from(new Uint32Array(api.memory.buffer, labelPtr, count));
const error = () => {
    const memory = new Uint8Array(api.memory.buffer);
    const start = api.abiss_watershed_last_error();
    return new TextDecoder().decode(memory.subarray(start, memory.indexOf(0, start)));
};
const watershed = () => api.abiss_watershed(affPtr, count * 3, 6, 8, 10,
    0.99999, 0.00005, 50, 50, labelPtr, count);
const agglomerate = threshold => api.abiss_watershed_agglomerate(affPtr, count * 3, 6, 8, 10,
    0.99999, 0.00005, 50, 50, threshold, labelPtr, count);

try {
    for (let axis = 0; axis < 3; ++axis) {
        const shape = [6, 8, 10];
        const affinities = new Float32Array(count * 3).fill(0.9);
        let contacts = 0;
        for (let z = 0; z < 10; ++z)
            for (let y = 0; y < 8; ++y)
                for (let x = 0; x < 6; ++x)
                    if ([x, y, z][axis] === shape[axis] / 2)
                        affinities[x + 6 * (y + 8 * z) + axis * count] = contacts++ % 2 ? 0.3 : 0.1;
        new Float32Array(api.memory.buffer, affPtr, count * 3).set(affinities);
        assert.equal(watershed(), 0, error());
        const baseline = labels();
        assert.notEqual(baseline[0], 0);
        assert.notEqual(baseline[count - 1], 0);
        assert.notEqual(baseline[0], baseline[count - 1]);
        for (const threshold of [0.25, 1]) {
            assert.equal(agglomerate(threshold), 0, error());
            assert.deepEqual(labels(), baseline, 'mean .2 must not merge despite maximum .3');
        }
        for (const threshold of [0, 0.15]) {
            assert.equal(agglomerate(threshold), 0, error());
            const merged = labels();
            assert.notEqual(merged[0], 0);
            assert.ok(merged.every(id => id === merged[0]), 'expected one larger segment');
        }
        new Uint32Array(api.memory.buffer, labelPtr, count).fill(0xdeadbeef);
        for (const bad of [-0.1, 1.1, Infinity, -Infinity, NaN]) {
            assert.equal(agglomerate(bad), 1);
            assert.match(error(), /agglomeration threshold/);
            assert.ok(labels().every(id => id === 0xdeadbeef), 'error partially wrote labels');
        }
        assert.equal(api.abiss_watershed_agglomerate(affPtr, count * 3 - 1, 6, 8, 10,
            0.99999, 0.00005, 50, 50, 0.15, labelPtr, count), 1);
        assert.match(error(), /buffer lengths/);
        assert.ok(labels().every(id => id === 0xdeadbeef));
        assert.equal(watershed(), 0, error());
        assert.equal(error(), '');
        assert.deepEqual(labels(), baseline);
        assert.deepEqual(new Float32Array(api.memory.buffer, affPtr, count * 3), affinities);
    }
    console.log('All standalone WebAssembly segmentation tests passed');
} finally {
    api.free(labelPtr);
    api.free(affPtr);
}
