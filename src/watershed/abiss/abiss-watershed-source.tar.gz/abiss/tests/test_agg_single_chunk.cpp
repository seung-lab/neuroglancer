#include "../examples/agg_single_chunk.hpp"
#include "../examples/ws_single_chunk.hpp"

#include <array>
#include <iostream>

namespace {

using Shape = std::array<std::size_t, 3>;

void require(bool condition, const char* message)
{
    if (!condition) {
        throw std::runtime_error(message);
    }
}

template<typename F>
void expect_invalid(F operation)
{
    try {
        operation();
    } catch (const std::invalid_argument&) {
        return;
    }
    throw std::runtime_error("invalid input was accepted");
}

void test_collection_and_boundaries()
{
    const Shape shape{4, 5, 3};
    const auto count = shape[0] * shape[1] * shape[2];
    const uint32_t other = std::numeric_limits<uint32_t>::max();
    for (std::size_t axis = 0; axis < 3; ++axis) {
        const auto split = shape[axis] / 2;
        std::vector<uint32_t> labels(count);
        std::vector<float> affinities(count * 3, 1);
        std::size_t area = 0;
        float sum = 0;
        for (std::size_t z = 0; z < shape[2]; ++z)
            for (std::size_t y = 0; y < shape[1]; ++y)
                for (std::size_t x = 0; x < shape[0]; ++x) {
                    const auto index = x + shape[0] * (y + shape[1] * z);
                    labels[index] = Shape{x, y, z}[axis] < split ? 7 : other;
                    if (Shape{x, y, z}[axis] == split) {
                        const float affinity = area % 2 == 0 ? 0.25f : 0.75f;
                        affinities[index + axis * count] = affinity;
                        sum += affinity;
                        ++area;
                    }
                }
        const auto original_affinities = affinities;
        const auto original_labels = labels;
        auto graph = abiss_demo::collect_region_graph(
            affinities.data(), labels.data(), shape[0], shape[1], shape[2]);
        require(graph.seg_indices == std::vector<seg_t>({7, other}), "sparse IDs were not mapped");
        require(graph.rg_vector.size() == 1, "expected one contacting label pair");
        const auto edge = graph.rg_vector.front();
        require(edge.v0 == 0 && edge.v1 == 1, "edge endpoints are not dense indices");
        require(edge.w.num == area && edge.w.sum == sum, "wrong channel, sum, or contact area");
        require(area == count / shape[axis], "contact face lost real-boundary voxels");
        require(graph.seg_size == std::vector<std::size_t>({split * area, count - split * area}),
                "incorrect voxel sizes");
        require(graph.supervoxel_counts == std::vector<std::size_t>({1, 1}),
                "real-boundary labels were frozen or counted as voxels");
        const auto merged = abiss_demo::agglomerate_chunk(
            affinities.data(), labels.data(), shape[0], shape[1], shape[2], 0.1f);
        require(std::all_of(merged.begin(), merged.end(), [&](auto id) { return id == merged[0]; }),
                "real-boundary labels did not merge");
        require(merged[0] != 0, "foreground was removed");
        require(abiss_demo::agglomerate_chunk(
                    affinities.data(), labels.data(), shape[0], shape[1], shape[2], 1) == labels,
                "threshold 1 should preserve every input ID");
        require(affinities == original_affinities && labels == original_labels,
                "input buffers were modified");
    }
}

void test_dynamic_weighted_mean()
{
    // AB: .9/1, AC: .2/2, BC: .8/1. After AB merges, (AB)-C is 1/3.
    const std::vector<uint32_t> labels{1, 2, 1, 3, 1, 3};
    std::vector<float> affinities(6 * 3, 0);
    affinities[1] = 0.9f;
    affinities[3] = 0.1f;
    affinities[5] = 0.1f;
    affinities[6 + 3] = 0.8f;
    auto graph = abiss_demo::collect_region_graph(affinities.data(), labels.data(), 2, 3, 1);
    require(graph.rg_vector.size() == 3, "triangle graph was not collected");
    require(graph.rg_vector[1].w.num == 2 && graph.rg_vector[1].w.sum == 0.2f,
            "parallel contacts were not summed");
    auto result = abiss_demo::agglomerate_chunk(affinities.data(), labels.data(), 2, 3, 1, 0.4f);
    require(result[0] == result[1] && result[0] == result[2] && result[0] == result[4],
            "highest-mean AB edge was not merged");
    require(result[3] == result[5] && result[3] != result[0],
            "used static thresholding, max affinity, or unweighted mean instead of updated sum/area");
    result = abiss_demo::agglomerate_chunk(affinities.data(), labels.data(), 2, 3, 1, 0.3f);
    require(std::all_of(result.begin(), result.end(), [&](auto id) { return id == result[0]; }),
            "updated shared-neighbor edge did not merge above its new threshold");
}

void test_remap_chains()
{
    const std::vector<uint32_t> labels{10, 20, 30, 40, 50, 60};
    std::vector<float> affinities(6 * 3, 0);
    affinities[1] = 0.95f;
    affinities[2] = 0.7f;
    affinities[3] = 0.9f;
    affinities[4] = 0.85f;
    affinities[5] = 0.8f;
    const auto result = abiss_demo::agglomerate_chunk(
        affinities.data(), labels.data(), 6, 1, 1, 0.5f);
    require(result == std::vector<uint32_t>(6, 30), "merge remap chains were not fully resolved");
}

void test_background_and_thresholds()
{
    const std::vector<uint32_t> labels{1, 0, 2, 3, 3, 0, 99};
    std::vector<float> affinities(7 * 3, 1);
    const auto result = abiss_demo::agglomerate_chunk(affinities.data(), labels.data(), 7, 1, 1);
    require(result[0] == 1 && result[6] == 99 && result[1] == 0 && result[5] == 0,
            "background or isolated labels changed");
    require(result[2] == result[3] && result[3] == result[4] && result[2] != 0,
            "contacting singleton-axis regions did not merge");
    const std::vector<uint32_t> background(7, 0);
    require(abiss_demo::agglomerate_chunk(affinities.data(), background.data(), 7, 1, 1) == background,
            "all-background input changed");
    const std::vector<uint32_t> pair{7, 9};
    affinities.assign(2 * 3, 0.5f);
    require(abiss_demo::agglomerate_chunk(affinities.data(), pair.data(), 2, 1, 1, 0.5f) == pair,
            "threshold comparison must be strict");
    require(abiss_demo::agglomerate_chunk(affinities.data(), pair.data(), 2, 1, 1, 0.49f)[1] == 7,
            "edge above threshold was not merged");
    affinities.assign(2 * 3, 0);
    const auto graph = abiss_demo::collect_region_graph(affinities.data(), pair.data(), 2, 1, 1);
    require(graph.rg_vector.size() == 1 && graph.rg_vector[0].w.num == 1,
            "zero-affinity contacts must remain in the collected graph");
    require(abiss_demo::agglomerate_chunk(affinities.data(), pair.data(), 2, 1, 1, 0) == pair,
            "zero-affinity edge should not merge at threshold 0");
    const uint32_t singleton = std::numeric_limits<uint32_t>::max();
    require(abiss_demo::agglomerate_chunk(affinities.data(), &singleton, 1, 1, 1)
                == std::vector<uint32_t>({singleton}), "singleton ID was lost");
}

void test_production_size_heuristic()
{
    const std::vector<uint32_t> labels{1, 2};
    const std::vector<float> affinities(2 * 3, 0.25f);
    auto graph = abiss_demo::collect_region_graph(affinities.data(), labels.data(), 2, 1, 1);
    graph.seg_size = {1'000'001, 9'000'001};
    graph.params.input_aff_threshold = 0.15f;
    const auto output = agglomerate_cc<mean_edge, mean_edge_greater, mean_edge_plus, mean_edge_limits>(
        graph, 0, graph.rg_vector.size(), mean_edge(0.15f, 1));
    require(output.remap.empty() && output.rej_rg_vector.size() == 1,
            "production low-affinity size rejection was bypassed");
}

void test_watershed_integration()
{
    std::vector<float> affinities(6 * 4 * 3 * 3, 0.9f);
    for (std::size_t z = 0; z < 3; ++z)
        for (std::size_t y = 0; y < 4; ++y)
            affinities[2 + 6 * (y + 4 * z)] = 0.2f;
    const auto labels = abiss_demo::watershed_chunk(
        affinities.data(), 6, 4, 3, 0.99999f, 0.00005f, 0, 0);
    require(labels.front() != 0 && labels.back() != 0 && labels.front() != labels.back(),
            "watershed fixture did not create two foreground regions");
    const auto result = abiss_demo::agglomerate_chunk(affinities.data(), labels.data(), 6, 4, 3);
    require(std::all_of(result.begin(), result.end(), [&](auto id) { return id == result[0]; }),
            "agglomeration failed to consume watershed output");
    require(abiss_demo::agglomerate_chunk(affinities.data(), labels.data(), 6, 4, 3, 0.25f) == labels,
            "higher agglomeration threshold should preserve the watershed regions");
}

void test_invalid_inputs()
{
    std::vector<float> affinities(2 * 3, 1);
    const std::vector<uint32_t> labels{1, 2};
    expect_invalid([&] { abiss_demo::agglomerate_chunk(nullptr, labels.data(), 2, 1, 1); });
    expect_invalid([&] { abiss_demo::agglomerate_chunk(affinities.data(), nullptr, 2, 1, 1); });
    expect_invalid([&] { abiss_demo::agglomerate_chunk(affinities.data(), labels.data(), 0, 1, 1); });
    expect_invalid([&] { abiss_demo::agglomeration_voxel_count(
        std::numeric_limits<std::size_t>::max(), 2, 2); });
    expect_invalid([&] { abiss_demo::agglomeration_voxel_count(
        static_cast<std::size_t>(std::numeric_limits<int>::max()) + 1, 1, 1); });
    for (auto bad : {-0.1f, 1.1f, std::numeric_limits<float>::infinity(),
                     std::numeric_limits<float>::quiet_NaN()}) {
        expect_invalid([&] { abiss_demo::agglomerate_chunk(
            affinities.data(), labels.data(), 2, 1, 1, bad); });
        affinities[0] = bad;
        expect_invalid([&] { abiss_demo::collect_region_graph(
            affinities.data(), labels.data(), 2, 1, 1); });
        affinities[0] = 1;
    }
}

} // namespace

int main()
{
    try {
        test_collection_and_boundaries();
        test_dynamic_weighted_mean();
        test_remap_chains();
        test_background_and_thresholds();
        test_production_size_heuristic();
        test_watershed_integration();
        test_invalid_inputs();
        std::cout << "All single-chunk agglomeration tests passed\n";
    } catch (const std::exception& error) {
        std::cerr << "test_agg_single_chunk: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
