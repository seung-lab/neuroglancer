#include "../examples/ws_agg_single_chunk.hpp"

#include <iostream>
#include <sstream>

namespace {

using Shape = std::array<std::size_t, 3>;

void require(bool condition, const char* message)
{
    if (!condition) {
        throw std::runtime_error(message);
    }
}

template<typename F>
void expect_invalid(F operation)
{
    try {
        operation();
    } catch (const std::invalid_argument&) {
        return;
    }
    throw std::runtime_error("invalid input was accepted");
}

std::vector<float> blocks(Shape shape, std::size_t axis)
{
    const auto count = shape[0] * shape[1] * shape[2];
    std::vector<float> affinities(count * 3, 0.9f);
    std::size_t contacts = 0;
    for (std::size_t z = 0; z < shape[2]; ++z)
        for (std::size_t y = 0; y < shape[1]; ++y)
            for (std::size_t x = 0; x < shape[0]; ++x) {
                if (Shape{x, y, z}[axis] == shape[axis] / 2) {
                    affinities[x + shape[0] * (y + shape[1] * z) + axis * count]
                        = contacts++ % 2 == 0 ? 0.1f : 0.3f;
                }
            }
    return affinities;
}

void require_uniform(const std::vector<uint32_t>& labels, bool foreground)
{
    require(!labels.empty(), "empty output");
    require((labels.front() != 0) == foreground, "unexpected foreground/background");
    require(std::all_of(labels.begin(), labels.end(), [&](auto id) { return id == labels.front(); }),
            "expected one uniform label");
}

void test_optional_agglomeration()
{
    std::ostringstream output;
    struct RestoreCout {
        std::streambuf* previous;
        ~RestoreCout() { std::cout.rdbuf(previous); }
    } restore{std::cout.rdbuf(output.rdbuf())};

    for (std::size_t axis = 0; axis < 3; ++axis) {
        const auto aff = blocks({6, 8, 10}, axis);
        const auto watershed = abiss::watershed_chunk(aff.data(), 6, 8, 10);
        require(abiss::watershed_agglomerate_chunk(aff.data(), 6, 8, 10) == watershed,
                "default must disable agglomeration and preserve exact watershed IDs");
        require(abiss::watershed_agglomerate_chunk(
                    aff.data(), 6, 8, 10, 0.99999f, 0.00005f, 0, 0, std::nullopt)
                    == abiss::watershed_chunk(aff.data(), 6, 8, 10, 0.99999f, 0.00005f, 0, 0),
                "explicitly disabled path changed watershed thresholds");
        require_uniform(abiss::watershed_agglomerate_chunk(
            aff.data(), 6, 8, 10, 0.99999f, 0.00005f, 50, 50, 0), true);
        require(abiss::watershed_agglomerate_chunk(
                    aff.data(), 6, 8, 10, 0.99999f, 0.00005f, 50, 50, 0.15f)
                    == abiss_demo::watershed_agglomerate_chunk(aff.data(), 6, 8, 10),
                "demo did not forward to the shared implementation");
        require(abiss::watershed_agglomerate_chunk(
                    aff.data(), 6, 8, 10, 0.99999f, 0.00005f, 0, 241)
                    == abiss::watershed_chunk(aff.data(), 6, 8, 10, 0.99999f, 0.00005f, 0, 241),
                "disabled path changed dust filtering");
    }
    require(output.str().empty(), "production agglomeration wrote to stdout");
}

void test_pipeline_and_boundaries()
{
    const Shape shape{6, 8, 10}; // Two 240-voxel regions survive default SIZE/DUST.
    for (std::size_t axis = 0; axis < 3; ++axis) {
        const auto affinities = blocks(shape, axis);
        const auto original = affinities;
        const auto watershed = abiss_demo::watershed_chunk(
            affinities.data(), shape[0], shape[1], shape[2]);
        const auto separate = abiss_demo::watershed_agglomerate_chunk(
            affinities.data(), shape[0], shape[1], shape[2],
            0.99999f, 0.00005f, 50, 50, 0.25f);
        require(separate == watershed, "mean .2 must not merge at AGG .25, despite maximum .3");
        require(separate.size() == shape[0] * shape[1] * shape[2], "halo was not removed");
        const auto left = separate.front();
        const auto right = separate.back();
        require(left != 0 && right != 0 && left != right, "expected two foreground regions");
        for (std::size_t z = 0; z < shape[2]; ++z)
            for (std::size_t y = 0; y < shape[1]; ++y)
                for (std::size_t x = 0; x < shape[0]; ++x) {
                    const auto expected = Shape{x, y, z}[axis] < shape[axis] / 2 ? left : right;
                    require(separate[x + shape[0] * (y + shape[1] * z)] == expected,
                            "incorrect channel layout or real-boundary voxel");
                }

        const auto merged = abiss_demo::watershed_agglomerate_chunk(
            affinities.data(), shape[0], shape[1], shape[2]);
        require_uniform(merged, true);
        require(merged == abiss_demo::agglomerate_chunk(
                    affinities.data(), watershed.data(), shape[0], shape[1], shape[2]),
                "combined result differs from explicit two-stage composition");
        require(affinities == original, "input buffer was modified");
    }
}

void test_watershed_thresholds()
{
    const auto affinities = blocks({6, 8, 10}, 0);
    const auto separate = abiss_demo::watershed_agglomerate_chunk(
        affinities.data(), 6, 8, 10, 0.99999f, 0.00005f, 0, 0, 1);
    require(separate.front() != 0 && separate.back() != 0 && separate.front() != separate.back(),
            "AGG 1 should preserve watershed regions");
    require_uniform(abiss_demo::watershed_agglomerate_chunk(
        affinities.data(), 6, 8, 10, 0.05f, 0.00005f, 0, 0, 1), true);
    require_uniform(abiss_demo::watershed_agglomerate_chunk(
        affinities.data(), 6, 8, 10, 0.99999f, 0.00005f, 241, 0, 1), true);
    require_uniform(abiss_demo::watershed_agglomerate_chunk(
        affinities.data(), 6, 8, 10, 0.99999f, 0.00005f, 0, 241, 0), false);
    require_uniform(abiss_demo::watershed_agglomerate_chunk(
        affinities.data(), 6, 8, 10, 0.99999f, 0.95f, 0, 0, 0), false);
}

void test_background_and_singleton_axis()
{
    std::vector<float> affinities(4 * 3 * 2 * 3, 0);
    require_uniform(abiss_demo::watershed_agglomerate_chunk(affinities.data(), 4, 3, 2), false);
    affinities.assign(1 * 2 * 3 * 3, 1);
    const auto labels = abiss_demo::watershed_agglomerate_chunk(
        affinities.data(), 1, 2, 3, 0.99999f, 0.00005f, 0, 0);
    require(labels.size() == 6, "singleton axis was lost");
    require_uniform(labels, true);
}

void test_invalid_inputs()
{
    std::vector<float> affinities(2 * 3, 1);
    expect_invalid([&] { abiss_demo::watershed_agglomerate_chunk(nullptr, 2, 1, 1); });
    expect_invalid([&] { abiss_demo::watershed_agglomerate_chunk(affinities.data(), 0, 1, 1); });
    expect_invalid([&] { abiss_demo::watershed_agglomerate_chunk(
        affinities.data(), std::numeric_limits<std::size_t>::max(), 1, 1); });
    expect_invalid([&] { abiss_demo::watershed_agglomerate_chunk(
        affinities.data(), 2, 1, 1, 0.5f, 0.5f); });
    for (auto bad : {-0.1f, 1.1f, std::numeric_limits<float>::infinity(),
                     std::numeric_limits<float>::quiet_NaN()}) {
        expect_invalid([&] { abiss_demo::watershed_agglomerate_chunk(
            affinities.data(), 2, 1, 1, 0.99999f, 0.00005f, 0, 0, bad); });
        affinities[0] = bad;
        expect_invalid([&] { abiss_demo::watershed_agglomerate_chunk(affinities.data(), 2, 1, 1); });
        affinities[0] = 1;
    }
}

} // namespace

int main()
{
    try {
        test_optional_agglomeration();
        test_pipeline_and_boundaries();
        test_watershed_thresholds();
        test_background_and_singleton_axis();
        test_invalid_inputs();
        std::cout << "All combined watershed/agglomeration tests passed\n";
    } catch (const std::exception& error) {
        std::cerr << "test_ws_agg_single_chunk: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
