#include "../src/seg/RegionGraphIO.hpp"

#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

using Edge = SimpleEdge<uint32_t, float>;

void require(bool condition, const char* message)
{
    if (!condition) {
        throw std::runtime_error(message);
    }
}

void require_edges(const std::vector<Edge>& actual, const std::vector<Edge>& expected)
{
    require(actual.size() == expected.size(), "wrong number of region-graph edges");
    for (std::size_t i = 0; i < actual.size(); ++i) {
        require(actual[i].s1 == expected[i].s1 && actual[i].s2 == expected[i].s2,
                "edge endpoints were not normalized or sorted");
        require(actual[i].affinity == expected[i].affinity && actual[i].area == expected[i].area,
                "edge affinity sums or areas changed");
    }
}

void write_edges(const std::string& filename, const std::vector<Edge>& edges)
{
    std::ofstream output(filename, std::ios::binary);
    output.write(reinterpret_cast<const char*>(edges.data()), edges.size() * sizeof(Edge));
    output.close();
    require(bool(output), "could not write region-graph fixture");
}

void test_file_utilities(const std::filesystem::path& directory)
{
    const auto filename = [&](const char* name) { return (directory / name).string(); };
    const std::vector<Edge> input{
        Edge(7, 9, 0.5f, 2), Edge(3, 7, 0.25f, 1),
        Edge(7, 3, 0.75f, 2), Edge(0, 7, 1, 1)};
    write_edges(filename("input.raw"), input);
    const auto graph = loadRegionGraph<uint32_t, float>(filename("input.raw"));
    require_edges(graph, {Edge(7, 3, 1, 3), Edge(9, 7, 0.5f, 2)});

    const SetContainer<uint32_t> incomplete{3, 7};
    const std::vector<Edge> expected_incomplete{Edge(7, 3, 1, 3)};
    std::vector<Edge> expected_complete{Edge(9, 7, 0.5f, 2)};
#ifdef MST_EDGE
    expected_complete.push_back(expected_complete.front());
#endif
    writeRegionGraph<uint32_t, float>(incomplete, graph,
        filename("incomplete.raw"), filename("complete.raw"));
    require_edges(read_array<Edge>(filename("incomplete.raw")), expected_incomplete);
    require_edges(read_array<Edge>(filename("complete.raw")), expected_complete);

    updateRegionGraph<uint32_t, float>(incomplete, filename("input.raw"),
        filename("updated-incomplete.raw"), filename("updated-complete.raw"));
    require_edges(read_array<Edge>(filename("updated-incomplete.raw")), expected_incomplete);
    require_edges(read_array<Edge>(filename("updated-complete.raw")), expected_complete);

    write_edges(filename("empty.raw"), {});
    require(loadRegionGraph<uint32_t, float>(filename("empty.raw")).empty(),
            "empty region graph gained edges");
    updateRegionGraph<uint32_t, float>(incomplete, filename("empty.raw"),
        filename("empty-incomplete.raw"), filename("empty-complete.raw"));
    require_edges(read_array<Edge>(filename("empty-incomplete.raw")), {});
    require_edges(read_array<Edge>(filename("empty-complete.raw")), {});

    write_edges(filename("background.raw"), {Edge(3, 0, 1, 1), Edge(0, 0, 1, 1)});
    require(loadRegionGraph<uint32_t, float>(filename("background.raw")).empty(),
            "background contacts must not become graph edges");
}

} // namespace

int main()
{
    try {
        const auto directory = std::filesystem::temp_directory_path() /
            ("abiss-region-graph-test-" + std::to_string(std::random_device{}()));
        require(std::filesystem::create_directory(directory), "could not create fixture directory");
        test_file_utilities(directory);
        std::filesystem::remove_all(directory);
        std::cout << "All region-graph file utility tests passed\n";
    } catch (const std::exception& error) {
        std::cerr << "test_affinity_region_graph: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
