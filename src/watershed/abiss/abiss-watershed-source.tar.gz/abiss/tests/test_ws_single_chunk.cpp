#include "../src/ws/single_chunk.hpp"
#include "../examples/ws_single_chunk.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <type_traits>
#include <vector>

namespace {

using Shape = std::array<std::size_t, 3>;

static_assert(std::is_same_v<decltype(abiss::watershed_chunk(nullptr, 1, 1, 1)),
                             std::vector<std::uint32_t>>,
              "single-chunk labels must be uint32_t");

void require(bool condition, const char* message)
{
    if (!condition) {
        throw std::runtime_error(message);
    }
}

template<typename F>
void expect_invalid(F operation)
{
    try {
        operation();
    } catch (const std::invalid_argument&) {
        return;
    }
    throw std::runtime_error("invalid input was accepted");
}

std::vector<float> blocks(Shape shape, std::size_t axis, std::size_t split, float bridge)
{
    const auto count = shape[0] * shape[1] * shape[2];
    std::vector<float> affinities(count * 3, 0.9f);
    for (std::size_t z = 0; z < shape[2]; ++z)
        for (std::size_t y = 0; y < shape[1]; ++y)
            for (std::size_t x = 0; x < shape[0]; ++x) {
                if (Shape{x, y, z}[axis] == split) {
                    affinities[x + shape[0] * (y + shape[1] * z) + axis * count] = bridge;
                }
            }
    return affinities;
}

void set_external_edges(std::vector<float>& affinities, Shape shape, float value)
{
    const auto count = shape[0] * shape[1] * shape[2];
    for (std::size_t z = 0; z < shape[2]; ++z)
        for (std::size_t y = 0; y < shape[1]; ++y)
            for (std::size_t x = 0; x < shape[0]; ++x)
                for (std::size_t axis = 0; axis < 3; ++axis) {
                    // Only the negative-neighbor external edges are stored in the input.
                    if (Shape{x, y, z}[axis] == 0) {
                        affinities[x + shape[0] * (y + shape[1] * z) + axis * count] = value;
                    }
                }
}

void require_uniform(const std::vector<uint32_t>& labels, bool foreground)
{
    require(!labels.empty(), "empty output");
    require((labels.front() != 0) == foreground, "unexpected foreground/background");
    require(std::all_of(labels.begin(), labels.end(), [&](auto id) { return id == labels.front(); }),
            "expected one uniform label");
}

void test_defaults_and_compatibility()
{
    std::ostringstream output;
    struct RestoreCout {
        std::streambuf* previous;
        ~RestoreCout() { std::cout.rdbuf(previous); }
    } restore{std::cout.rdbuf(output.rdbuf())};

    const auto aff = blocks({6, 4, 3}, 0, 2, 0.2f);
    require(abiss::chunk_voxel_count(6, 4, 3) == 72, "incorrect voxel count");
    const auto defaults = abiss::watershed_chunk(aff.data(), 6, 4, 3);
    require(defaults == abiss::watershed_chunk(aff.data(), 6, 4, 3, 0.99999f, 0.00005f, 50, 50),
            "defaults differ from explicit thresholds");
    require_uniform(defaults, true); // SIZE joins 24 + 48 voxels; the result survives DUST.
    require(output.str().empty(), "production watershed wrote to stdout");
    require(abiss_demo::chunk_voxel_count(6, 4, 3) == 72, "demo voxel-count alias differs");
    require(abiss_demo::watershed_chunk(aff.data(), 6, 4, 3) == defaults,
            "demo watershed alias differs");
}

void test_boundaries_and_layout()
{
    const Shape shape{6, 8, 10};
    for (std::size_t axis = 0; axis < 3; ++axis) {
        const auto split = shape[axis] / 2;
        auto affinities = blocks(shape, axis, split, 0);
        const auto original = affinities;
        const auto labels = abiss::watershed_chunk(affinities.data(), shape[0], shape[1], shape[2]);
        require(labels.size() == shape[0] * shape[1] * shape[2], "halo was not removed");
        const auto left = labels.front();
        const auto right = labels.back();
        require(left != 0 && right != 0 && left != right, "expected two foreground regions");
        for (std::size_t z = 0; z < shape[2]; ++z)
            for (std::size_t y = 0; y < shape[1]; ++y)
                for (std::size_t x = 0; x < shape[0]; ++x) {
                    const auto expected = Shape{x, y, z}[axis] < split ? left : right;
                    require(labels[x + shape[0] * (y + shape[1] * z)] == expected,
                            "incorrect channel layout or real-boundary voxel");
                }
        require(affinities == original, "input buffer was modified");
        for (auto value : {0.0f, 1.0f}) {
            auto external = affinities;
            set_external_edges(external, shape, value);
            require(abiss::watershed_chunk(external.data(), shape[0], shape[1], shape[2]) == labels,
                    "external-edge values changed real-boundary labels");
        }
    }
}

void test_thresholds()
{
    auto aff = blocks({6, 4, 3}, 0, 2, 0.2f); // Region sizes 24 and 48.
    auto separate = abiss::watershed_chunk(aff.data(), 6, 4, 3, 0.99999f, 0.00005f, 0, 0);
    require(separate.front() != 0 && separate.back() != 0 && separate.front() != separate.back(),
            "unexpected joining with SIZE=0");
    require_uniform(abiss::watershed_chunk(aff.data(), 6, 4, 3, 0.1f, 0.00005f, 0, 0), true);
    // The bridge is weaker than each region's internal edges, so HIGH equality is decisive.
    require_uniform(abiss::watershed_chunk(aff.data(), 6, 4, 3, 0.2f, 0.00005f, 0, 0), true);
    require(abiss::watershed_chunk(aff.data(), 6, 4, 3, 0.99999f, 0.00005f, 24, 0) == separate,
            "region of exactly SIZE was merged");
    require_uniform(abiss::watershed_chunk(aff.data(), 6, 4, 3, 0.99999f, 0.00005f, 25, 0), true);

    std::vector<float> uniform(4 * 3 * 2 * 3, 0.3f);
    require_uniform(abiss::watershed_chunk(uniform.data(), 4, 3, 2, 0.99999f, 0.1f, 0, 0), true);
    require_uniform(abiss::watershed_chunk(uniform.data(), 4, 3, 2, 0.99999f, 0.3f, 0, 0), false);
    require_uniform(abiss::watershed_chunk(uniform.data(), 4, 3, 2, 0.99999f, 0.5f, 0, 0), false);

    aff = blocks({6, 3, 2}, 0, 2, 0); // Region sizes 12 and 24, both touch real boundaries.
    auto dust = abiss::watershed_chunk(aff.data(), 6, 3, 2, 0.99999f, 0.00005f, 0, 13);
    for (std::size_t i = 0; i < dust.size(); ++i) {
        require((dust[i] != 0) == (i % 6 >= 2), "DUST did not remove only the small region");
    }
    require(abiss::watershed_chunk(aff.data(), 6, 3, 2, 0.99999f, 0.00005f, 0, 24) == dust,
            "boundary region of exactly DUST was removed");
    require_uniform(abiss::watershed_chunk(aff.data(), 6, 3, 2, 0.99999f, 0.00005f, 0, 25), false);
    require_uniform(abiss::watershed_chunk(uniform.data(), 4, 3, 2, 0.99999f, 0.00005f, 0, 24), true);
    require_uniform(abiss::watershed_chunk(uniform.data(), 4, 3, 2, 0.99999f, 0.00005f, 0, 25), false);
}

void test_background_and_singleton_axis()
{
    std::vector<float> aff(4 * 3 * 2 * 3, 0);
    require_uniform(abiss::watershed_chunk(aff.data(), 4, 3, 2), false);
    set_external_edges(aff, {4, 3, 2}, 1);
    require_uniform(abiss::watershed_chunk(aff.data(), 4, 3, 2, 1, 0, 0, 0), false);
    for (auto shape : {Shape{1, 2, 3}, Shape{2, 1, 3}, Shape{2, 3, 1}}) {
        aff.assign(6 * 3, 1);
        auto labels = abiss::watershed_chunk(aff.data(), shape[0], shape[1], shape[2],
                                            0.99999f, 0.00005f, 0, 0);
        require(labels.size() == 6, "singleton axis was lost");
        require_uniform(labels, true);
    }
    aff.assign(3, 1); // A lone voxel has no internal edge, even when all stored edges are HIGH.
    auto singleton = abiss::watershed_chunk(aff.data(), 1, 1, 1, 1, 0, 0, 0);
    require(singleton.size() == 1, "single voxel was lost");
    require_uniform(singleton, false);
}

void test_invalid_inputs()
{
    std::vector<float> aff(4 * 3 * 2 * 3, 1);
    expect_invalid([&] { abiss::watershed_chunk(nullptr, 4, 3, 2); });
    const auto max_dim = std::numeric_limits<std::size_t>::max();
    for (std::size_t axis = 0; axis < 3; ++axis) {
        for (auto bad_dim : {std::size_t{0}, max_dim, max_dim - 1}) {
            Shape shape{4, 3, 2};
            shape[axis] = bad_dim;
            expect_invalid([&] { abiss::chunk_voxel_count(shape[0], shape[1], shape[2]); });
            expect_invalid([&] { abiss::watershed_chunk(aff.data(), shape[0], shape[1], shape[2]); });
        }
    }
    expect_invalid([&] { abiss::chunk_voxel_count(65536, 65536, 2); });
    // Raw voxels fit the ID range, but adding the halo exceeds the padded-volume limit.
    expect_invalid([&] { abiss::chunk_voxel_count(std::size_t{1} << 28, 1, 1); });
    expect_invalid([&] { abiss::watershed_chunk(aff.data(), 4, 3, 2, 0.1f, 0.9f); });
    expect_invalid([&] { abiss::watershed_chunk(aff.data(), 4, 3, 2, 0.5f, 0.5f); });
    const auto inf = std::numeric_limits<float>::infinity();
    const auto nan = std::numeric_limits<float>::quiet_NaN();
    for (auto bad : {-0.1f, 1.1f, -inf, inf, nan}) {
        expect_invalid([&] { abiss::watershed_chunk(aff.data(), 4, 3, 2, bad, 0.1f); });
        expect_invalid([&] { abiss::watershed_chunk(aff.data(), 4, 3, 2, 0.9f, bad); });
    }
    for (auto bad : {-0.1f, 1.1f, -inf, inf, nan}) {
        aff[0] = bad;
        expect_invalid([&] { abiss::watershed_chunk(aff.data(), 4, 3, 2); });
    }
}

} // namespace

int main()
{
    try {
        test_defaults_and_compatibility();
        test_boundaries_and_layout();
        test_thresholds();
        test_background_and_singleton_axis();
        test_invalid_inputs();
        std::cout << "All single-chunk watershed tests passed\n";
    } catch (const std::exception& error) {
        std::cerr << "test_ws_single_chunk: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
