// Standalone: g++ -std=c++17 tests/test_mean_agglomeration_kernel.cpp -o /tmp/mean_agglomeration_kernel
#include "../src/agg/agglomeration.hpp"
#include "../src/ws/types.hpp" // The shared kernel must not define region_graph.

#include <cmath>
#include <initializer_list>
#include <sstream>
#include <stdexcept>

namespace {

using Data = agglomeration_data_t<mean_edge, mean_edge_greater>;

void require(bool condition, const char * message)
{
    if (!condition) {
        throw std::runtime_error(message);
    }
}

Data graph(size_t vertices, std::initializer_list<edge_t<mean_edge>> edges,
           aff_t input_threshold = 0.15f)
{
    Data data;
    data.rg_vector = edges;
    data.incident.resize(vertices);
    data.supervoxel_counts.assign(vertices, 1);
    data.seg_size.assign(vertices, 10);
    data.seg_indices.resize(vertices);
    std::iota(data.seg_indices.begin(), data.seg_indices.end(), seg_t(100));
    data.params.input_aff_threshold = input_threshold;
    return data;
}

agglomeration_output_t<mean_edge> run(Data & data, aff_t threshold,
                                     std::ostream * progress = nullptr)
{
    // Each graph is consumed once: adjacency handles cannot outlive this call's heap.
    return agglomerate_cc<mean_edge, mean_edge_greater, mean_edge_plus, mean_edge_limits>(
        data, 0, data.rg_vector.size(), mean_edge(threshold, 1), progress);
}

void test_heap_and_frozen_helpers()
{
    auto data = graph(3, {{0, 1, mean_edge(0.9f)}, {0, 2, mean_edge(0.2f)}});
    auto heap = populate_heap(data, 0, data.rg_vector.size(), mean_edge(0.5f));
    require(heap.size() == 1 && heap.top().edge == &data.rg_vector[0], "wrong heap selection");
    require(data.incident[0].at(1).valid_handle(), "active adjacency handle missing");
    require(!data.incident[0].at(2).valid_handle(), "inactive edge acquired a handle");
    require(!frozen_neighbors(data.incident[0], data.supervoxel_counts), "unexpected frozen neighbor");
    data.supervoxel_counts[2] |= frozen;
    require(is_frozen(data.supervoxel_counts[2]), "frozen bit not detected");
    require(frozen_neighbors(data.incident[0], data.supervoxel_counts), "frozen neighbor missed");
}

void test_weighted_shared_neighbors()
{
    // AB merges first. AC and BC then combine to mean 1/3, not .8 or .45.
    // Both orientations exercise retaining/replacing an inactive heap handle.
    for (bool reverse : {false, true}) {
        auto data = graph(3, {{0, 1, mean_edge(0.9f)},
                              {0, 2, reverse ? mean_edge(0.8f) : mean_edge(0.2f, 2)},
                              {1, 2, reverse ? mean_edge(0.2f, 2) : mean_edge(0.8f)}});
        data.sem_counts = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        std::ostringstream progress;
        const auto output = run(data, 0.4f, &progress);
        require(output.remap == std::vector<std::pair<seg_t, seg_t>>{{1, 0}}, "wrong first merge");
        require(output.merged_rg_vector.size() == 1, "mean update failed to stop merging");
        require(data.supervoxel_counts == std::vector<size_t>({2, 0, 1}), "supervoxel count lost");
        require(data.seg_size == std::vector<size_t>({20, 0, 10}), "voxel size lost");
        require(data.sem_counts[0] == sem_array_t({5, 7, 9}) && data.sem_counts[1] == sem_array_t{},
                "semantic counts not combined");
        const auto live = std::find_if(data.rg_vector.begin(), data.rg_vector.end(),
                                       [](const auto & e) { return e.w.num != 0; });
        require(live != data.rg_vector.end() && live->w.num == 3
                    && std::abs(live->w.sum - 1.0f) < 1e-6f, "contact sum/area not preserved");
        require(progress.str().empty(), "small graph produced periodic progress");
    }
    auto data = graph(3, {{0, 1, mean_edge(0.9f)}, {0, 2, mean_edge(0.2f, 2)},
                          {1, 2, mean_edge(0.8f)}});
    require(run(data, 0.3f).remap.size() == 2, "updated mean above threshold did not merge");
}

void test_production_heuristics()
{
    const agglomeration_param_t defaults{};
    require(defaults.optimal_number_of_partitions == 1, "header acquired native scheduling dependency");
    require(defaults.size_params.small_voxel_threshold == 1'000'000
                && defaults.size_params.large_voxel_threshold == 10'000'000,
            "production size defaults changed");

    auto frozen_data = graph(2, {{0, 1, mean_edge(0.9f)}});
    frozen_data.supervoxel_counts[0] |= frozen;
    const auto frozen_output = run(frozen_data, 0.15f);
    require(frozen_output.remap.empty() && frozen_output.res_rg_vector.size() == 1
                && is_frozen(frozen_data.supervoxel_counts[1]), "frozen rejection changed");

    for (aff_t affinity : {aff_t(0.25), aff_t(0.4)}) {
        auto data = graph(2, {{0, 1, mean_edge(affinity)}});
        data.seg_size = {1'000'001, 9'000'001};
        const auto output = run(data, 0.15f);
        if (affinity < defaults.size_params.aff_threshold) {
            require(output.remap.empty() && output.rej_rg_vector.size() == 1, "size rejection bypassed");
        } else {
            require(output.remap.size() == 1, "high-affinity size override changed");
        }
    }

    const sem_array_t axon{100'000, 0, 0};
    const sem_array_t dendrite{0, 100'000, 0};
    require(sem_label(dendrite) == std::make_pair(size_t(1), size_t(100'000)), "wrong semantic label");
    require(!sem_can_merge(axon, dendrite, defaults.sem_params), "confident semantic conflict allowed");
    require(sem_can_merge(axon, sem_array_t{0, 99'999, 0}, defaults.sem_params),
            "weak semantic signal rejected");
    require(sem_can_merge(axon, sem_array_t{50'000, 50'000, 0}, defaults.sem_params),
            "ambiguous semantic signal rejected");
    for (aff_t affinity : {aff_t(0.5), aff_t(0.6)}) {
        auto data = graph(2, {{0, 1, mean_edge(affinity)}});
        data.sem_counts = {axon, dendrite};
        const auto output = run(data, 0.15f);
        if (affinity == defaults.sem_params.aff_threshold) {
            require(output.remap.empty() && output.sem_rg_vector.size() == 1, "semantic rejection bypassed");
        } else {
            require(output.remap.size() == 1, "high-affinity semantic override changed");
        }
    }

    for (size_t area : {size_t(50), size_t(51)}) {
        auto data = graph(2, {{0, 1, mean_edge(0.4f * area, area)}}, 0.5f);
        const auto output = run(data, 0.3f);
        require(output.remap.size() == (area == 50 ? 1u : 0u), "twig area threshold changed");
        require(output.twig_rg_vector.size() == output.remap.size(), "twig merge not recorded");
    }
}

void test_empty_strict_threshold_and_mst()
{
    auto empty = graph(0, {});
    require(run(empty, 0.5f).remap.empty(), "empty graph merged");
    auto equal = graph(2, {{0, 1, mean_edge(0.5f)}});
    require(run(equal, 0.5f).remap.empty(), "threshold must be strict");

    agglomeration_data_t<mst_edge, mst_edge_greater> mst;
    mst.incident.resize(2);
    mst.rg_vector = {{0, 1, mst_edge(0.9f, 1, atomic_edge_t(100, 101, 0.9f, 1))}};
    mst.supervoxel_counts = {1, 1};
    mst.seg_indices = {100, 101};
    mst.seg_size = {10, 10};
    mst.params.input_aff_threshold = 0.15f;
    const auto output = agglomerate_cc<mst_edge, mst_edge_greater, mst_edge_plus, mst_edge_limits>(
        mst, 0, mst.rg_vector.size(), mst_edge(0.5f));
    require(output.remap.size() == 1 && output.merged_rg_vector[0].w.repr.area == 1,
            "MST edge specialization changed");
}

} // namespace

int main()
{
    try {
        test_heap_and_frozen_helpers();
        test_weighted_shared_neighbors();
        test_production_heuristics();
        test_empty_strict_threshold_and_mst();
        std::cout << "All shared mean-agglomeration kernel tests passed\n";
    } catch (const std::exception & error) {
        std::cerr << "mean_agglomeration_kernel: " << error.what() << '\n';
        return 1;
    }
}
