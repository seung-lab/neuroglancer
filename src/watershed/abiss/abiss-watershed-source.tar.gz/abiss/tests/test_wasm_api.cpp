#include "../src/ws/wasm.h"
#include "../src/ws/agg_single_chunk.hpp"

#include <iostream>

namespace {

void require(bool condition, const char* message)
{
    if (!condition) {
        throw std::runtime_error(message);
    }
}

void test_api()
{
    constexpr uint32_t count = 6 * 8 * 10;
    std::vector<float> affinities(count * 3, 0.9f);
    for (uint32_t z = 0; z < 10; ++z)
        for (uint32_t y = 0; y < 8; ++y)
            affinities[3 + 6 * (y + 8 * z)] = y % 2 == 0 ? 0.1f : 0.3f;
    const auto original = affinities;
    const auto watershed = abiss::watershed_chunk(affinities.data(), 6, 8, 10);
    require(watershed.front() != 0 && watershed.back() != 0
                && watershed.front() != watershed.back(), "fixture needs two watershed regions");

    std::vector<uint32_t> labels(count, 0);
    require(abiss_watershed(affinities.data(), count * 3, 6, 8, 10,
                            0.99999f, 0.00005f, 50, 50, labels.data(), count) == 0,
            "original C ABI failed");
    require(labels == watershed, "original ABI changed watershed output");
    for (float threshold : {0.0f, 0.15f, 0.25f, 1.0f}) {
        require(abiss_watershed_agglomerate(affinities.data(), count * 3, 6, 8, 10,
                    0.99999f, 0.00005f, 50, 50, threshold, labels.data(), count) == 0,
                "agglomeration C ABI failed");
        require(labels == abiss::watershed_agglomerate_chunk(affinities.data(), 6, 8, 10,
                    0.99999f, 0.00005f, 50, 50, threshold), "C and C++ APIs differ");
        if (threshold < 0.2f) {
            require(labels.front() != 0 && std::all_of(labels.begin(), labels.end(),
                [&](auto id) { return id == labels.front(); }), "threshold did not merge regions");
        } else {
            require(labels == watershed, "threshold should preserve the two regions");
        }
        require(abiss_watershed_last_error()[0] == '\0', "success retained an error");
    }

    constexpr uint32_t sentinel = 0xdeadbeef;
    const std::vector<uint32_t> untouched(count, sentinel);
    labels = untouched;
    auto expect_failure = [&](auto operation) {
        require(operation() == 1, "invalid input did not return status 1");
        require(abiss_watershed_last_error()[0] != '\0', "missing input error message");
        require(labels == untouched, "failure partially wrote output labels");
    };
    for (float bad : {-0.1f, 1.1f, -std::numeric_limits<float>::infinity(),
                     std::numeric_limits<float>::infinity(), std::numeric_limits<float>::quiet_NaN()}) {
        expect_failure([&] { return abiss_watershed_agglomerate(affinities.data(), count * 3,
            6, 8, 10, 0.99999f, 0.00005f, 50, 50, bad, labels.data(), count); });
    }
    expect_failure([&] { return abiss_watershed_agglomerate(affinities.data(), count * 3 - 1,
        6, 8, 10, 0.99999f, 0.00005f, 50, 50, 0.15f, labels.data(), count); });
    expect_failure([&] { return abiss_watershed_agglomerate(affinities.data(), count * 3,
        6, 8, 10, 0.99999f, 0.00005f, 50, 50, 0.15f, labels.data(), count - 1); });
    expect_failure([&] { return abiss_watershed_agglomerate(affinities.data(), count * 3,
        6, 8, 10, 0.99999f, 0.00005f, 50, 50, 0.15f, nullptr, count); });
    expect_failure([&] { return abiss_watershed_agglomerate(nullptr, count * 3,
        6, 8, 10, 0.99999f, 0.00005f, 50, 50, 0.15f, labels.data(), count); });
    expect_failure([&] { return abiss_watershed_agglomerate(affinities.data(), count * 3,
        0, 8, 10, 0.99999f, 0.00005f, 50, 50, 0.15f, labels.data(), count); });
    expect_failure([&] { return abiss_watershed_agglomerate(affinities.data(), count * 3,
        UINT32_MAX, 8, 10, 0.99999f, 0.00005f, 50, 50, 0.15f, labels.data(), count); });
    expect_failure([&] { return abiss_watershed_agglomerate(affinities.data(), count * 3,
        6, 8, 10, 0.5f, 0.5f, 50, 50, 0.15f, labels.data(), count); });
    affinities[1] = std::numeric_limits<float>::quiet_NaN();
    expect_failure([&] { return abiss_watershed_agglomerate(affinities.data(), count * 3,
        6, 8, 10, 0.99999f, 0.00005f, 50, 50, 0.15f, labels.data(), count); });
    affinities = original;
    require(abiss_watershed(affinities.data(), count * 3, 6, 8, 10,
                            0.99999f, 0.00005f, 50, 50, labels.data(), count) == 0,
            "watershed did not recover after an error");
    require(abiss_watershed_last_error()[0] == '\0', "error was not cleared on next call");
    require(labels == watershed && affinities == original, "recovery or input immutability failed");
}

} // namespace

int main()
{
    try {
        test_api();
        std::cout << "All segmentation C ABI tests passed\n";
    } catch (const std::exception& error) {
        std::cerr << "test_wasm_api: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
