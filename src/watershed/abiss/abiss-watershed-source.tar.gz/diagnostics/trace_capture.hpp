#pragma once
#include <cstdint>
#include <cstring>
inline uint32_t case120_trace[65536] = {};
inline uint32_t case120_trace_size = 0;
inline void trace_record(uint32_t type, uint64_t v0, uint64_t v1, float sum,
                         uint64_t area, uint64_t survivor, uint64_t c0, uint64_t c1) {
    if (case120_trace_size + 8 > 65536) return;
    uint32_t bits; std::memcpy(&bits, &sum, 4);
    for (auto value : {type, uint32_t(v0), uint32_t(v1), bits, uint32_t(area),
                       uint32_t(survivor), uint32_t(c0), uint32_t(c1)})
        case120_trace[case120_trace_size++] = value;
}
