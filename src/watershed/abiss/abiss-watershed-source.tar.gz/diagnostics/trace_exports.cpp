#include <initializer_list>
#include "trace_capture.hpp"
extern "C" uint32_t* trace_data() { return case120_trace; }
extern "C" uint32_t trace_size() { return case120_trace_size; }
extern "C" void trace_reset() { case120_trace_size = 0; }
