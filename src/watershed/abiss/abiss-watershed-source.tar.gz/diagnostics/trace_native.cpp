#define main original_native_main
#include "/tmp/abiss-agglomeration-delivery.HloEtF/native_runner.cpp"
#undef main
#include "trace_capture.hpp"
int main(int argc, char** argv) {
    if(argc != 2) return 64;
    std::ifstream input(argv[1], std::ios::binary); input.ignore(8);
    const auto x=read_u32(input),y=read_u32(input),z=read_u32(input);
    const auto high=read_f32(input),low=read_f32(input);
    const auto size=read_u32(input),dust=read_u32(input),enabled=read_u32(input);
    const auto agg=read_f32(input); const auto n=x*y*z;
    std::vector<float> aff(3*n); for(auto&v:aff)v=read_f32(input);
    std::vector<uint32_t> labels(n);
    const auto status=abiss_watershed_agglomerate(aff.data(),3*n,x,y,z,high,low,size,dust,agg,labels.data(),n);
    if(status)return status;
    std::cout<<"{\"labels\":[";
    for(uint32_t i=0;i<n;++i)std::cout<<(i?",":"")<<labels[i];
    std::cout<<"],\"trace_words\":[";
    for(uint32_t i=0;i<case120_trace_size;++i)std::cout<<(i?",":"")<<case120_trace[i];
    std::cout<<"]}\n";
}
