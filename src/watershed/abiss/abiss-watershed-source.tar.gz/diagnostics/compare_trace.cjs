'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root='/tmp/abiss-agglomeration-delivery.HloEtF',dir=__dirname;
const c=JSON.parse(fs.readFileSync(root+'/repro_case120.json'));
const observed=JSON.parse(fs.readFileSync(root+'/repro_case120_outputs.json'));
const mod=new WebAssembly.Module(fs.readFileSync(dir+'/trace.wasm'));
assert.deepEqual(WebAssembly.Module.imports(mod),[{module:'env',name:'emscripten_notify_memory_growth',kind:'function'}]);
const w=new WebAssembly.Instance(mod,{env:{emscripten_notify_memory_growth(){}}}).exports;
w._initialize();const n=c.dims.reduce((a,b)=>a*b,1),ap=w.malloc(12*n),lp=w.malloc(4*n);
new Float32Array(w.memory.buffer,ap,3*n).set(c.affinities);w.trace_reset();
assert.equal(w.abiss_watershed_agglomerate(ap,3*n,...c.dims,c.high,c.low,c.size,c.dust,c.agg_threshold,lp,n),0);
const wasmLabels=Array.from(new Uint32Array(w.memory.buffer,lp,n));
const wasmWords=Array.from(new Uint32Array(w.memory.buffer,w.trace_data(),w.trace_size()));
const native=JSON.parse(fs.readFileSync(dir+'/native-trace.json'));
assert.deepEqual(wasmLabels,observed.runs[0].enabled_wasm,'instrumented WASM must reproduce delivered WASM labels');
assert.deepEqual(native.labels,observed.runs[0].enabled_native,'instrumented native must reproduce original native labels');
function rows(words){const output=[];for(let i=0;i<words.length;i+=8){const r=words.slice(i,i+8),bits=Buffer.alloc(4);bits.writeUInt32LE(r[3]);output.push({kind:r[0]===1?'merge':'incident',v0:r[1],v1:r[2],sum:bits.readFloatLE(),area:r[4],mean:r[4]?bits.readFloatLE()/r[4]:null,survivor:r[5],count0:r[6],count1:r[7]});}return output;}
const a=rows(wasmWords),b=rows(native.trace_words);
const mergesA=a.filter(r=>r.kind==='merge'),mergesB=b.filter(r=>r.kind==='merge');
const firstDiff=(a,b)=>{let i=0;while(i<Math.min(a.length,b.length)&&JSON.stringify(a[i])===JSON.stringify(b[i]))++i;return i;};
const mi=firstDiff(mergesA,mergesB),ti=firstDiff(a,b);
const report={scope:'Instrumented TEMPORARY source copies only; delivered source/binary unchanged',
  instrumented_outputs_reproduce_original_exactly:true,
  first_event_divergence:{index:ti,wasm:a[ti],native:b[ti]},
  first_merge_divergence:{index:mi,one_based:mi+1,common_prefix:mergesA.slice(0,mi),wasm:mergesA[mi],native:mergesB[mi]},
  wasm_merges:mergesA,native_merges:mergesB,wasm_trace:a,native_trace:b,
  artifacts:{temporary_build:dir,instrumented_wasm_sha256:crypto.createHash('sha256').update(fs.readFileSync(dir+'/trace.wasm')).digest('hex')}};
fs.writeFileSync(root+'/repro_case120_trace.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({first_event_divergence:report.first_event_divergence,first_merge_divergence:report.first_merge_divergence,merges:[mergesA.length,mergesB.length]},null,2));
