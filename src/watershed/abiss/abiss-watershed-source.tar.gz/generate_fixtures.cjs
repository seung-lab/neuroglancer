#!/usr/bin/env node
'use strict';
// Geometry-only oracle: this file never loads WebAssembly or invokes native code.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

const HIGH = 0.99999;
const LOW = 0.00005;
const THRESHOLDS = [null, 0, 0.2, 0.25, 0.3, 1];

function slabFixtures(axis, dims, size = 0, dust = 0, prefix = 'slab') {
  const n = dims.reduce((a, b) => a * b, 1);
  const split = dims[axis] / 2;
  assert.equal(split, Math.floor(split));
  const affinities = new Array(3 * n);
  const slabs = new Array(n);
  let contacts = 0;
  let sum = 0;
  for (let z = 0; z < dims[2]; ++z) {
    for (let y = 0; y < dims[1]; ++y) {
      for (let x = 0; x < dims[0]; ++x) {
        const c = [x, y, z];
        const i = x + dims[0] * (y + dims[1] * z);
        // z/y/x nested seed scan first encounters the low-coordinate slab.
        slabs[i] = c[axis] < split ? 1 : 2;
        for (let channel = 0; channel < 3; ++channel) {
          // Deliberately nonzero OUTSIDE edges at the negative real boundaries.
          // Correct negative-neighbor semantics exclude these; they are not contacts.
          let value = c[channel] === 0 ? 1 : 0.875;
          if (channel === axis && c[axis] === split) {
            value = contacts++ % 2 === 0 ? 0.125 : 0.375;
            sum += value;
          }
          affinities[channel * n + i] = value;
        }
      }
    }
  }
  assert.equal(contacts, n / dims[axis]);
  assert.equal(contacts % 2, 0);
  assert.equal(sum / contacts, 0.25); // dyadic arithmetic: exact even in float32
  assert.ok(size === 0 || n / 2 >= size);
  assert.ok(dust === 0 || n / 2 >= dust);
  return THRESHOLDS.map(agg_threshold => ({
    name: `${prefix}_${'xyz'[axis]}_${agg_threshold === null ? 'disabled' : `agg_${agg_threshold}`}`,
    dims: [...dims], affinities: [...affinities], high: HIGH, low: LOW,
    size, dust, agg_threshold,
    // Only one graph edge exists. Its mean is exactly .25; the test is STRICT >.
    // Equal supervoxel counts preserve sorted endpoint 1 when merging the pair.
    labels: agg_threshold !== null && agg_threshold < 0.25
      ? new Array(n).fill(1) : [...slabs],
  }));
}

function makeFixtures() {
  const fixtures = [];
  for (let axis = 0; axis < 3; ++axis) {
    const dims = [4, 4, 4];
    dims[axis] = 6;
    fixtures.push(...slabFixtures(axis, dims)); // 96 voxels; 48 per slab
  }
  // Default SIZE/DUST are safe here: each slab has 108 voxels, not 48.
  fixtures.push(...slabFixtures(0, [6, 6, 6], 50, 50, 'default_slab'));
  for (const agg_threshold of [null, 0]) {
    const baseline = fixtures[0];
    fixtures.push({
      ...baseline, name: `dust_${agg_threshold === null ? 'disabled' : 'agg_0'}`,
      dims: [...baseline.dims], affinities: [...baseline.affinities],
      size: 0, dust: 50, agg_threshold, labels: new Array(96).fill(0),
    }); // both 48-voxel components disappear BEFORE agglomeration
    const dims = [3, 2, 2];
    const n = 12;
    const affinities = new Array(3 * n).fill(0);
    for (let z = 0; z < dims[2]; ++z)
      for (let y = 0; y < dims[1]; ++y)
        for (let x = 0; x < dims[0]; ++x) {
          const c = [x, y, z];
          const i = x + dims[0] * (y + dims[1] * z);
          for (let channel = 0; channel < 3; ++channel)
            if (c[channel] === 0) affinities[channel * n + i] = 1;
        }
    fixtures.push({
      name: `background_${agg_threshold === null ? 'disabled' : 'agg_0'}`,
      dims, affinities, high: HIGH, low: LOW, size: 0, dust: 0,
      agg_threshold, labels: new Array(n).fill(0),
    }); // no in-volume contact exceeds LOW; outside values must be ignored
  }
  // Independent NG-peer dynamic-mean case, specified geometrically, not measured.
  // A = left 2 columns; B = top-right 2 voxels; C = remaining right 6 voxels.
  // Seed order A/B/C gives IDs 1/2/3. AB=.9, BC=.8, AC=(.6+.6+0)/3.
  // After AB merges, its C interface has FIVE contacts: (.6+.6+0+.8+.8)/5=.56.
  const affinities = new Array(48).fill(1);
  [0.9, 0.6, 0.6, 0].forEach((v, y) => { affinities[2 + 4 * y] = v; });
  affinities[16 + 2 + 4] = 0.8;
  affinities[16 + 3 + 4] = 0.8;
  for (const agg_threshold of [null, 0.58, 0.55]) {
    const labels = agg_threshold === null
      ? [1,1,2,2, 1,1,3,3, 1,1,3,3, 1,1,3,3]
      : agg_threshold === 0.58
        ? [1,1,1,1, 1,1,3,3, 1,1,3,3, 1,1,3,3]
        : new Array(16).fill(1);
    fixtures.push({
      name: `dynamic_ng_peer_${agg_threshold === null ? 'disabled' : `agg_${agg_threshold}`}`,
      dims: [4, 4, 1], affinities: [...affinities], high: HIGH, low: LOW,
      size: 0, dust: 0, agg_threshold, labels,
    });
  }
  return fixtures;
}

// Arrays stay compact (one line per field), while each fixture remains readable.
function serialize(fixtures) {
  return '[\n' + fixtures.map(f => '  {\n' + Object.entries(f)
    .map(([key, value]) => `    ${JSON.stringify(key)}: ${JSON.stringify(value)}`)
    .join(',\n') + '\n  }').join(',\n') + '\n]\n';
}

if (require.main === module) {
  assert.ok(process.argv.length <= 3 && (!process.argv[2] || process.argv[2] === '--check'),
    'usage: node generate_fixtures.cjs [--check]');
  const file = path.join(__dirname, 'fixtures.json');
  const content = serialize(makeFixtures());
  if (process.argv[2] === '--check') {
    assert.equal(fs.readFileSync(file, 'utf8'), content, 'fixtures.json differs from analytic oracle');
    console.log('PASS: fixtures.json exactly matches the geometry-only oracle');
  } else {
    fs.writeFileSync(file, content);
    console.log(`Wrote ${makeFixtures().length} analytic fixtures to ${file}`);
  }
}
module.exports = { makeFixtures };
