#!/usr/bin/env node
'use strict';
// Observed failure reproducer, NOT an analytic fixture oracle.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const cp = require('node:child_process');
const crypto = require('node:crypto');
const root = __dirname;
const runner = path.resolve(process.argv[2] || path.join(root, 'repro_native_runner'));
const wasmFile = path.resolve(process.argv[3] || path.join(root, 'abiss_watershed.wasm'));
const caseFile = path.join(root, 'repro_case120.bin');
const outputFile = path.join(root, 'repro_case120_outputs.json');
const sha = b => crypto.createHash('sha256').update(b).digest('hex');
const raw = fs.readFileSync(caseFile);
assert.equal(raw.toString('ascii', 0, 8), 'ABISSC01');
const dims = [8, 12, 16].map(i => raw.readUInt32LE(i));
const n = dims.reduce((a, b) => a * b, 1);
assert.equal(raw.length, 44 + 12 * n);
const high = raw.readFloatLE(20), low = raw.readFloatLE(24);
const size = raw.readUInt32LE(28), dust = raw.readUInt32LE(32), agg = raw.readFloatLE(40);
const affinities = Float32Array.from({ length: 3 * n }, (_, i) => raw.readFloatLE(44 + 4 * i));
const wasmBytes = fs.readFileSync(wasmFile);
const module_ = new WebAssembly.Module(wasmBytes);
const imports = WebAssembly.Module.imports(module_);
assert.deepEqual(imports, [{ module: 'env', name: 'emscripten_notify_memory_growth', kind: 'function' }]);
function native(enabled) {
  const input = Buffer.from(raw);
  input.writeUInt32LE(enabled ? 1 : 0, 36);
  const p = cp.spawnSync(runner, [], { input, timeout: 30000 });
  assert.equal(p.status, 0, p.error?.message || p.stderr.toString());
  assert.equal(p.stdout.length, 4 * n);
  return Array.from({ length: n }, (_, i) => p.stdout.readUInt32LE(4 * i));
}
function freshWasm() {
  const w = new WebAssembly.Instance(module_, { env: { emscripten_notify_memory_growth() {} } }).exports;
  w._initialize(); // Exactly once for each of the five independent instances.
  return enabled => {
    const ap = w.malloc(12 * n), lp = w.malloc(4 * n);
    assert.ok(ap && lp);
    try {
      new Float32Array(w.memory.buffer, ap, 3 * n).set(affinities);
      const args = [ap, 3 * n, ...dims, high, low, size, dust];
      const status = enabled ? w.abiss_watershed_agglomerate(...args, agg, lp, n)
        : w.abiss_watershed(...args, lp, n);
      assert.equal(status, 0);
      return Array.from(new Uint32Array(w.memory.buffer, lp, n));
    } finally { w.free(lp); w.free(ap); }
  };
}
function canonicalize(labels) {
  const ids = new Map([[0, 0]]);
  let next = 1;
  return labels.map(id => {
    if (!ids.has(id)) ids.set(id, next++);
    return ids.get(id);
  });
}
const runs = [];
for (let i = 0; i < 5; ++i) {
  const wasm = freshWasm();
  const disabledWasm = wasm(false), disabledNative = native(false);
  assert.deepEqual(disabledWasm, disabledNative, 'disabled exact labels');
  const enabledWasm = wasm(true), enabledNative = native(true);
  const canonicalWasm = canonicalize(enabledWasm), canonicalNative = canonicalize(enabledNative);
  assert.deepEqual(canonicalWasm, canonicalNative, 'enabled partitions, including label 0');
  assert.deepEqual(enabledWasm.map(v => v === 0), enabledNative.map(v => v === 0), 'identical background');
  const foreground = v => [...new Set(v.filter(id => id !== 0))];
  assert.equal(foreground(enabledWasm).length, 1, 'WASM single foreground component');
  assert.equal(foreground(enabledNative).length, 1, 'native single foreground component');
  const run = { run: i + 1, disabled_wasm: disabledWasm, disabled_native: disabledNative,
    enabled_wasm: enabledWasm, enabled_native: enabledNative, canonical_wasm: canonicalWasm,
    canonical_native: canonicalNative, wasm_foreground_ids: foreground(enabledWasm),
    native_foreground_ids: foreground(enabledNative), background_voxels: enabledWasm.filter(v => v === 0).length,
    exact_enabled_ids: JSON.stringify(enabledWasm) === JSON.stringify(enabledNative) };
  if (runs.length) {
    for (const key of ['disabled_wasm', 'disabled_native', 'enabled_wasm', 'enabled_native'])
      assert.deepEqual(run[key], runs[0][key], `${key}: output changed across independent runs`);
  }
  runs.push(run);
}
// Independently count initial region contacts to establish actual equal scores.
const edges = new Map(), strides = [1, dims[0], dims[0] * dims[1]];
const labels = runs[0].disabled_wasm;
for (let i = 0; i < n; ++i) {
  const coords = [i % dims[0], Math.floor(i / dims[0]) % dims[1], Math.floor(i / strides[2])];
  for (let channel = 0; channel < 3; ++channel) {
    if (coords[channel] === 0) continue;
    const a = labels[i], b = labels[i - strides[channel]];
    if (!a || !b || a === b) continue;
    const ids = [Math.min(a, b), Math.max(a, b)], key = ids.join('/');
    if (!edges.has(key)) edges.set(key, { ids, sum: 0, area: 0 });
    const edge = edges.get(key);
    edge.sum += affinities[channel * n + i]; ++edge.area;
  }
}
const groups = new Map();
for (const edge of edges.values()) {
  const mean = edge.sum / edge.area;
  if (!groups.has(mean)) groups.set(mean, []);
  groups.get(mean).push(edge.ids);
}
const equalScoreGroups = [...groups].filter(([, pairs]) => pairs.length > 1)
  .map(([mean, pairs]) => ({ mean, count: pairs.length, pairs }));
assert.ok(equalScoreGroups.length, 'initial graph must exhibit actual equal-score edges');
const report = { scope: 'Bounded diagnosis of observed case 120; NOT an analytic oracle or full exact-ID PASS',
  initial_graph_equal_score_groups: equalScoreGroups,
  case: { path: caseFile, sha256: sha(raw), dims, high, low, size, dust, agg_threshold: agg },
  wasm: { path: wasmFile, sha256: sha(wasmBytes), imports, independent_instances: 5, initialize_calls_per_instance: 1 },
  native: { path: runner, sha256: sha(fs.readFileSync(runner)), independent_processes: 10 },
  checks: { disabled_exact: true, enabled_partitions_equal: true, background_equal: true,
    single_foreground_component: true, stable_across_five_runs: true,
    enabled_exact_ids_equal: runs.every(r => r.exact_enabled_ids) }, runs };
fs.writeFileSync(outputFile, JSON.stringify(report, null, 2) + '\n');
console.log(`PASS: partition/background/single-component/stability across 5 runs; enabled exact IDs ${report.checks.enabled_exact_ids_equal ? 'MATCH' : 'DIFFER'}`);
console.log(`Observed survivors: WASM ${runs[0].wasm_foreground_ids}, native ${runs[0].native_foreground_ids}; background ${runs[0].background_voxels}/${n}`);
console.log(outputFile);
