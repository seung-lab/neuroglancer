# Independent analytic oracle

`generate_fixtures.cjs` computes only geometry and explicit label arrays. It never
loads WASM, runs a kernel, or accepts measured labels. `fixtures.json` has 31
cases (24 enabled, 7 disabled); `null` disables agglomeration, **numeric 0 enables**.
Dimensions are `[X,Y,Z]`, voxel index `x + X*(y + Y*z)`, affinity index
`channel*X*Y*Z + voxel`, channels pointing to the **negative** X/Y/Z neighbor.
Nonzero outside-facing affinities deliberately test real-boundary exclusion.

## Seed IDs, not merely equivalent partitions

The exported source establishes the scan rule:

- `source/abiss/src/ws/basic_watershed.hpp`: `FOR_EACH_3` expands its arguments in
  nested order; seed traversal supplies Z,Y,X (X innermost), `next_id = 1`, and a
  newly discovered component consumes the next ID. A voxel follows a neighbor
  when its affinity equals the local maximum or is at least HIGH, provided the
  local maximum exceeds LOW.
- `source/abiss/src/ws/single_chunk.hpp`: the wrapper pads the volume, masks all
  six real boundaries to LOW, and passes boundary flags. Outside values cannot
  supply a foreground connection; the Z singleton is handled the same way.
- `source/abiss/src/ws/agglomeration.hpp`: SIZE=0 cannot premerge distinct
  watershed components; DUST=0 retains them. Survivor relabeling scans original
  IDs in ascending order. Default SIZE/DUST=50 are used only for 108-voxel slabs.
- `source/abiss/src/agg/single_chunk.hpp`: region IDs and initial edges are sorted;
  graph supervoxel counts initially equal 1; final output preserves survivor IDs,
  rather than compacting them.
- `source/abiss/src/agg/agglomeration.hpp`: a two-region tie keeps the first
  endpoint (`auto s = v0`, changed only when its supervoxel count is smaller).
  These tiny cases do not trigger the large-region size heuristic.

Thus IDs below follow from seed order and the pair-survivor rule, not kernel
observations. Separate old-binary disabled checks corroborate them without
being their source.

## Two slabs, all three axes

For each axis, use a 6-long split axis and two 4-long axes: 96 voxels, 48/slab.
All in-slab contacts are `.875`, all 16 cross-slab contacts alternate `.125` and
`.375`. Every voxel has an in-slab `.875` neighbor, so no directed watershed
connection crosses the plane. Each slab is internally connected. The low-axis
slab's seed is encountered first: its label is 1, the other slab's label is 2.

The single graph edge has mean `(8*.125 + 8*.375)/16 = .25` **exactly in float32**.
Strict `mean > threshold` therefore merges to ID 1 at 0 and .2, and retains the
1/2 slab labels at .25, .3, and 1. The .3 case rejects max-contact semantics
(maximum .375), while .25 rejects a non-strict comparison. HIGH=.99999,
LOW=.00005, SIZE=DUST=0. A 6x6x6 X-slab variant repeats all six cases with
SIZE=DUST=50 (108 voxels per slab).

Background cases have zero in-volume affinities and outside-facing values 1;
no maximum exceeds LOW, hence all labels are 0. Dust cases use the 48-voxel
slabs with SIZE=0,DUST=50: both disappear **before** enabled agglomeration.

## Dynamic NG-peer case

Shape 4x4x1; initially all three affinity planes equal 1. In X channel set x=2
at successive rows to `[.9,.6,.6,0]`; in Y channel set row 1, x=2 and x=3 to .8.
All other in-volume contacts remain 1. HIGH=.99999, LOW=.00005, SIZE=DUST=0.

The maximum-1 components are A=left two columns, B=top-right two voxels,
C=remaining right six voxels. Scan order assigns A/B/C IDs 1/2/3:

```
1 1 2 2
1 1 3 3
1 1 3 3
1 1 3 3
```

AB has one .9 contact; BC has two .8 contacts; AC has three contacts `.6,.6,0`.
AB merges first to ID 1. The updated shared (A+B)-C interface counts **all five**
contacts: `(.6+.6+0+.8+.8)/5 = .56` (float32 rounding remains safely between .55
and .58). At .58 only AB merges, giving first row `[1,1,1,1]` and other rows
`[1,1,3,3]` with the ID-3 gap intact. At .55 everything becomes ID 1. This tests
weighted dynamic means, weak/zero contact area, and preservation of surviving IDs.

## Scope

Analytic cases have no ambiguous competing edge priorities. Arbitrary enabled
random graphs can have equal-priority edges; the current kernel does not specify
an endpoint tie-breaker for heap updates over unordered incident maps. See
`VERIFICATION.md` for the observed native/WASM survivor-ID discrepancy. No
expected fixture labels were changed to accommodate it.
