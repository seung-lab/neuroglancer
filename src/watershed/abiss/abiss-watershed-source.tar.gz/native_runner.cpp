// SPDX-License-Identifier: GPL-3.0-or-later
// Tiny binary stdin/file adapter to the EXACT C ABI in ws/wasm.h; no JSON library.
// Build: g++ -std=c++17 -O2 -I "$SOURCE/src" native_runner.cpp \
//          "$SOURCE/src/ws/wasm.cpp" -o native_runner
// Protocol (little endian): "ABISSC01" (8 bytes), x/y/z (3*u32),
// HIGH/LOW (2*f32), SIZE/DUST (2*u32), enabled (u32: 0 or 1), agg (f32),
// followed by 3*x*y*z f32 affinities, channel-slowest, x-fastest.
// Success stdout is exactly x*y*z little-endian uint32 labels, with no header.
// Errors go to stderr, with nonzero exit status. No batch framing or trailing bytes.
#include "ws/wasm.h"

#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <vector>

static uint32_t read_u32(std::istream& input)
{
    unsigned char b[4];
    if (!input.read(reinterpret_cast<char*>(b), 4)) {
        throw std::runtime_error("truncated input");
    }
    return uint32_t(b[0]) | (uint32_t(b[1]) << 8) |
           (uint32_t(b[2]) << 16) | (uint32_t(b[3]) << 24);
}

static float read_f32(std::istream& input)
{
    static_assert(sizeof(float) == 4 && std::numeric_limits<float>::is_iec559,
                  "IEEE-754 float32 required");
    const uint32_t bits = read_u32(input);
    float value;
    std::memcpy(&value, &bits, sizeof(value));
    return value;
}

static void write_u32(std::ostream& output, uint32_t value)
{
    const unsigned char b[] = {
        static_cast<unsigned char>(value), static_cast<unsigned char>(value >> 8),
        static_cast<unsigned char>(value >> 16), static_cast<unsigned char>(value >> 24)
    };
    output.write(reinterpret_cast<const char*>(b), 4);
}

int main(int argc, char** argv)
{
    try {
        if (argc > 2) throw std::runtime_error("usage: native_runner [case.bin|-]");
        std::ifstream file;
        std::istream* input = &std::cin;
        if (argc == 2 && std::strcmp(argv[1], "-") != 0) {
            file.open(argv[1], std::ios::binary);
            if (!file) throw std::runtime_error("cannot open input file");
            input = &file;
        }
        char magic[8];
        if (!input->read(magic, sizeof(magic)) || std::memcmp(magic, "ABISSC01", 8) != 0)
            throw std::runtime_error("bad or missing ABISSC01 magic");
        const uint32_t x = read_u32(*input);
        const uint32_t y = read_u32(*input);
        const uint32_t z = read_u32(*input);
        const float high = read_f32(*input);
        const float low = read_f32(*input);
        const uint32_t size = read_u32(*input);
        const uint32_t dust = read_u32(*input);
        const uint32_t enabled = read_u32(*input);
        const float agg = read_f32(*input);
        // Driver safety cap, not a change to the kernel's dimensional contract.
        constexpr uint64_t cap = 1'000'000;
        if (!x || !y || !z || x > cap || y > cap || z > cap ||
            uint64_t(x) * y > cap || uint64_t(x) * y * z > cap)
            throw std::runtime_error("runner requires 1..1000000 voxels");
        if (enabled > 1) throw std::runtime_error("enabled must be 0 or 1");
        const uint32_t n = x * y * z;
        std::vector<float> affinities(3 * n);
        for (auto& value : affinities) value = read_f32(*input);
        if (input->peek() != std::char_traits<char>::eof())
            throw std::runtime_error("trailing input bytes");
        const auto original = affinities;
        std::vector<uint32_t> labels(n, 0xdeadbeef);
        const int status = enabled
            ? abiss_watershed_agglomerate(affinities.data(), 3 * n, x, y, z,
                  high, low, size, dust, agg, labels.data(), n)
            : abiss_watershed(affinities.data(), 3 * n, x, y, z,
                  high, low, size, dust, labels.data(), n);
        if (status != 0) {
            std::cerr << "C ABI status " << status << ": " << abiss_watershed_last_error() << '\n';
            return status;
        }
        if (abiss_watershed_last_error()[0] != '\0')
            throw std::runtime_error("successful C ABI call left a nonempty error");
        if (std::memcmp(original.data(), affinities.data(), affinities.size() * sizeof(float)) != 0)
            throw std::runtime_error("C ABI modified input affinities");
        for (const auto label : labels) write_u32(std::cout, label);
        if (!std::cout) throw std::runtime_error("cannot write output");
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "native_runner: " << error.what() << '\n';
        return 64;
    }
}
